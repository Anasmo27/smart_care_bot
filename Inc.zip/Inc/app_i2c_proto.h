/*
 * app_i2c_proto.h
 *
 *  Created on: Apr 24, 2026
 *      Author: ASUS
 */
#ifndef APP_I2C_PROTO_H
#define APP_I2C_PROTO_H
#include "main.h"
#include "bts7960.h"
#include "encoder.h"
#include "motion.h"
#include "curve.h"
#include "mpu9250.h"
#include "ld06_lidar.h" // <<< إدراج هيدر الليدار الجديد
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum
{
    ROBOT_MODE_IDLE = 0,
    ROBOT_MODE_STRAIGHT,
    ROBOT_MODE_CURVE,
    ROBOT_MODE_TURN,
    ROBOT_MODE_FAULT
} robot_mode_t;

typedef enum
{
    STOP_REASON_NONE = 0,
    STOP_REASON_TARGET_REACHED,
    STOP_REASON_TIMEOUT,
    STOP_REASON_MANUAL,
    STOP_REASON_WATCHDOG,
    STOP_REASON_FAULT,
    STOP_REASON_NO_PROGRESS
} stop_reason_t;

typedef struct
{
    float ax_g;
    float ay_g;
    float az_g;

    float gx_dps;
    float gy_dps;
    float gz_dps;

    int16_t mx;
    int16_t my;
    int16_t mz;

    float heading_deg;
    float yaw_gyro;
    float yaw_fused;
} imu_avg_t;

#define FRAME_SOF1              0xAA
#define FRAME_SOF2              0x55

#define PKT_TYPE_CMD            0x10
#define PKT_TYPE_RESP           0x20

#define CMD_LED_ON              0x01
#define CMD_LED_OFF             0x02
#define CMD_STATUS              0x07
#define CMD_RESET_WD            0x08
#define CMD_STOP                0x09
#define CMD_CAR_CTRL            0x0A
#define CMD_GET_MOTION_STATE    0x0B
#define CMD_GET_ENCODERS        0x0C
#define CMD_GET_FAULTS          0x0D
#define CMD_GET_IMU_RAW         0x0E
#define CMD_GET_IMU_YAW         0x0F
#define CMD_GET_ODOM            0x10
#define CMD_MOVE_CM_FWD         0x11
#define CMD_MOVE_CM_BWD         0x12
#define CMD_TURN_DEG_R          0x13
#define CMD_TURN_DEG_L          0x14

// === أوامر الليدار الجديدة حسب הـ Architecture Document ===
#define CMD_LIDAR_INFO          0x20
#define CMD_LIDAR_STATUS        0x21
#define CMD_LIDAR_CHUNK         0x22

#define RESP_OK                 0x00
#define RESP_UNKNOWN_CMD        0x01
#define RESP_BAD_FRAME          0x02
#define RESP_BAD_CHECKSUM       0x03
#define RESP_BAD_LEN            0x04
#define RESP_BAD_ARG            0x05

#define I2C_RX_MAX              32
#define I2C_TX_MAX              128 // تم التوسعة عشان يكفي Chunk الليدار اللي مساحته 64 بايت

#define I2C_CMD_HEADER_LEN      6
#define I2C_CMD_MIN_FRAME_LEN   7
#define I2C_RESP_OVERHEAD       8

#define FAULT_NONE              0x00
#define FAULT_I2C_ERROR         0x01
#define FAULT_IMU_ERROR         0x02

#define CAR_MODE_F              0x01
#define CAR_MODE_B              0x02
#define CAR_MODE_R              0x03
#define CAR_MODE_L              0x04
#define CAR_MODE_FR             0x05
#define CAR_MODE_FL             0x06
#define CAR_MODE_BR             0x07
#define CAR_MODE_BL             0x08

#define IMU_ACC_SCALE_G_X1000   1000.0f
#define IMU_GYRO_SCALE_DPS_X100 100.0f
#define IMU_ANGLE_SCALE_X100    100.0f

#define IMU_AVG_SAMPLES         10U
#define IMU_SAMPLE_DELAY_MS     2U
#define IMU_MAX_TRIES           20U

#define I2C_WD_TIMEOUT_MS       1500U

#define ROBOT_WHEEL_DIAMETER_CM 6.5f
#define ROBOT_TICKS_PER_REV     11952.0f
#define ROBOT_TICKS_PER_CM      606.0f
#define ROBOT_TICKS_PER_CM_M1   606.0f
#define ROBOT_TICKS_PER_CM_M2   606.0f

/* Fixed speed policy */
#define STRAIGHT_SPEED_LOW        120
#define STRAIGHT_SPEED_HIGH       200
#define STRAIGHT_SPEED_THRESHOLD  160
#define TURN_FIXED_SPEED          120
#define STRAIGHT_SPEED_MIN_CMD   120
#define STRAIGHT_SPEED_MAX_CMD   200

/* Compatibility aliases used inside app_i2c_proto.c */
#define DIST_SPEED_LOW            STRAIGHT_SPEED_LOW
#define DIST_SPEED_HIGH           STRAIGHT_SPEED_HIGH
#define DIST_SPEED_SPLIT          STRAIGHT_SPEED_THRESHOLD

/* Distance-motion advanced path tuning */
#define DIST_ADV_ACCEL_COUNTS     220
#define DIST_ADV_STOP_DEADBAND    10
#define DIST_ADV_BRAKE_MIN_PWM    30

/* Turn-by-angle tuning */
#define TURN_CTRL_TOLERANCE_DEG    1.5f
#define TURN_CTRL_SLOW_WINDOW_DEG  28.0f
#define TURN_CTRL_MIN_PWM          45
#define TURN_CTRL_TIMEOUT_MS       5000U
#define TURN_CTRL_STARTUP_GUARD_MS 20U
#define TURN_CTRL_START_DETECT_DEG 3.0f
#define TURN_CTRL_IMU_WARMUP_SAMPLES 6U
#define TURN_CTRL_ANGLE_CMD_SCALE  0.92f

/* Encoder balancing tuning for straight distance motion only */
#define DIST_BAL_DIFF_DEADBAND_TICKS   8
#define DIST_BAL_MAX_TRIM_PWM          18
#define DIST_BAL_TRIM_DIVISOR          16
#define DIST_BAL_NEAR_END_DISABLE      80
#define DIST_BAL_START_ENABLE_TICKS    90
#define DIST_BAL_LOW_SPEED_THRESHOLD   140
#define DIST_BAL_LOW_SPEED_GAIN_PCT    170U
#define DIST_BAL_REVERSE_GAIN_PCT      185U

extern I2C_HandleTypeDef hi2c1;
extern I2C_HandleTypeDef hi2c3;
extern UART_HandleTypeDef huart2;

extern bts7960_t M1, M2;
extern encoder_t ENC1, ENC2;
extern motion_t MV1, MV2;
extern curve_t CV;
extern mpu9250_t IMU;

extern uint8_t i2c_rx_buf[I2C_RX_MAX];
extern uint8_t i2c_rx_shadow[I2C_RX_MAX];
extern uint8_t i2c_tx_buf[I2C_TX_MAX];

extern volatile uint8_t i2c_rx_len;
extern volatile uint8_t i2c_shadow_len;
extern volatile uint8_t i2c_tx_len;
extern volatile uint8_t i2c_frame_ready;
extern volatile uint8_t i2c_shadow_ready;
extern volatile uint8_t i2c_error_flag;

extern volatile uint8_t i2c_rx_stage;
extern volatile uint8_t i2c_expected_len;

extern uint8_t i2c_system_ok;
extern uint8_t i2c_fault_flags;
extern uint8_t i2c_watchdog_counter;

extern uint32_t last_watchdog_tick;
extern uint32_t last_i2c_cmd_tick;

extern volatile uint8_t dbg_i2c_rx_done;
extern volatile uint8_t dbg_i2c_tx_done;
extern volatile uint8_t dbg_i2c_error_seen;

extern uint8_t imu_ready;

extern volatile robot_mode_t g_robot_mode;
extern volatile stop_reason_t g_stop_reason;

void app_i2c_slave_start_listen(void);
void app_i2c_build_default_response(void);
void app_i2c_build_error_response(uint8_t seq, uint8_t cmd, uint8_t status);
void app_i2c_process_frame(void);
void app_i2c_update_system_status(void);
void app_i2c_print_error(void);
void app_turn_update(void);
uint8_t app_turn_is_active(void);

void app_straight_balance_update(void);

#ifdef __cplusplus
}
#endif

#endif
