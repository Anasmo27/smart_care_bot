/*
 * bts7960.h
 *
 *  Created on: Mar 6, 2026
 *      Author: ASUS
 */

#ifndef INC_BTS7960_H_
#define INC_BTS7960_H_

// Core/Inc/bts7960.h
#pragma once

#include "main.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
  TIM_HandleTypeDef *htim;
  uint32_t ch_rpwm;
  uint32_t ch_lpwm;
  uint16_t period;                 // ARR (e.g., 4199)

  GPIO_TypeDef *ren_port;
  uint16_t ren_pin;
  GPIO_TypeDef *len_port;
  uint16_t len_pin;

  // ramp state
  int16_t pwm_target;              // -255..255 (requested)
  int16_t pwm_current;             // -255..255 (applied)
  uint8_t enabled;                 // 0/1

  // ramp config
  uint16_t ramp_dt_ms;             // e.g., 10ms
  int16_t  ramp_step;              // e.g., 3 PWM units per tick
  uint32_t last_ms;
} bts7960_t;

void bts_init(bts7960_t *m,
              TIM_HandleTypeDef *htim,
              uint32_t ch_rpwm,
              uint32_t ch_lpwm,
              uint16_t period,
              GPIO_TypeDef *ren_port, uint16_t ren_pin,
              GPIO_TypeDef *len_port, uint16_t len_pin);

void bts_set_ramp(bts7960_t *m, uint16_t dt_ms, int16_t step);

void bts_enable(bts7960_t *m);
void bts_disable(bts7960_t *m);            // EN low + PWM=0 immediately
void bts_stop(bts7960_t *m);               // target=0 (will ramp down to 0)

void bts_set_target_pwm(bts7960_t *m, int16_t pwm_signed_255); // sets target only
void bts_tick(bts7960_t *m, uint32_t now_ms);                   // apply ramp + output

int16_t bts_get_target(const bts7960_t *m);
int16_t bts_get_current(const bts7960_t *m);
uint8_t bts_is_enabled(const bts7960_t *m);

#ifdef __cplusplus
}
#endif


#endif /* INC_BTS7960_H_ */
