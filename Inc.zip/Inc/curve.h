/*
 * curve.h
 *
 *  Created on: Mar 13, 2026
 *      Author: ASUS
 */

#ifndef INC_CURVE_H_
#define INC_CURVE_H_



#include "main.h"
#include "bts7960.h"
#include "encoder.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum
{
    CURVE_IDLE = 0,
    CURVE_RUNNING,
    CURVE_DONE
} curve_state_t;

typedef struct
{
    bts7960_t *outer_motor;
    bts7960_t *inner_motor;

    encoder_t *outer_enc;
    encoder_t *inner_enc;

    int8_t outer_dir;
    int8_t inner_dir;

    int32_t outer_start;
    int32_t inner_start;

    int32_t outer_target;   // counts
    int32_t inner_target;   // counts

    int16_t outer_speed;    // pwm
    int16_t inner_speed;    // pwm

    int32_t ratio_num;      // inner / outer
    int32_t ratio_den;

    uint8_t active;
    curve_state_t state;
} curve_t;

void curve_init(curve_t *c);

void curve_start(curve_t *c,
                 bts7960_t *outer_motor, encoder_t *outer_enc, int8_t outer_dir,
                 bts7960_t *inner_motor, encoder_t *inner_enc, int8_t inner_dir,
                 int32_t outer_steps, int16_t outer_speed,
                 int32_t ratio_num, int32_t ratio_den);

void curve_update(curve_t *c);
void curve_stop(curve_t *c);

curve_state_t curve_get_state(curve_t *c);

#ifdef __cplusplus
}
#endif



#endif /* INC_CURVE_H_ */
