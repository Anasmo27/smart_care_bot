/*
 * encoder.h
 *
 *  Created on: Mar 8, 2026
 *      Author: ASUS
 */

#ifndef INC_ENCODER_H_
#define INC_ENCODER_H_


#include "main.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct
{
    TIM_HandleTypeDef *htim;

    int32_t count_accum;     // عداد ممتد 32-bit
    uint16_t last_cnt;       // آخر قيمة خام من التايمر
} encoder_t;

void encoder_init(encoder_t *enc, TIM_HandleTypeDef *htim);
void encoder_reset(encoder_t *enc);
void encoder_update(encoder_t *enc);
int32_t encoder_get_count(encoder_t *enc);

#ifdef __cplusplus
}
#endif




#endif /* INC_ENCODER_H_ */
