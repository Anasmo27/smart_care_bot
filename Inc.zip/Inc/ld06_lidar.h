/*
 * ld06_lidar.h
 *
 *  Created on: May 3, 2026
 *      Author: ASUS
 */

#ifndef INC_LD06_LIDAR_H_
#define INC_LD06_LIDAR_H_

#include "main.h"
#include <stdint.h>

// حسب الدوكيومنت: أقصى عدد للنقاط المحفوظة هو 360 نقطة (2000 بايت تقريباً)
#define MAX_LIDAR_POINTS 360

// حجم الـ DMA Circular Buffer لاستقبال الـ UART (حسب الدوكيومنت: 256)
#define LIDAR_RX_BUF_SIZE 256

// هيكل النقطة الواحدة (كما طلب الـ Document: 4 bytes)
typedef struct {
    uint16_t angle_deg_x100; // الزاوية مضروبة في 100 (مثال: 90.5 درجة = 9050)
    uint16_t distance_mm;    // المسافة بالملليمتر
} LidarPoint_t;

// هيكل المسحة الكاملة (Latest Scan) التي سيسحبها الـ ESP32
typedef struct {
    uint16_t scan_id;        // رقم المسحة لضمان عدم سحب بيانات قديمة
    uint16_t point_count;    // عدد النقاط الفعلية في هذه المسحة
    LidarPoint_t points[MAX_LIDAR_POINTS];
} LidarScan_t;

// المتغيرات العامة
extern LidarScan_t current_scan;
extern uint8_t lidar_rx_buffer[LIDAR_RX_BUF_SIZE];

// الدوال
void LD06_Init(void);
void LD06_Process_DMA_Buffer(UART_HandleTypeDef *huart);


#endif /* INC_LD06_LIDAR_H_ */
