/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define REN1_Pin GPIO_PIN_13
#define REN1_GPIO_Port GPIOC
#define A2_Pin GPIO_PIN_0
#define A2_GPIO_Port GPIOA
#define B2_Pin GPIO_PIN_1
#define B2_GPIO_Port GPIOA
#define DEBUG_TX_Pin GPIO_PIN_2
#define DEBUG_TX_GPIO_Port GPIOA
#define DEBUG_RX_Pin GPIO_PIN_3
#define DEBUG_RX_GPIO_Port GPIOA
#define A1_Pin GPIO_PIN_5
#define A1_GPIO_Port GPIOA
#define RPWM1_Pin GPIO_PIN_6
#define RPWM1_GPIO_Port GPIOA
#define LPWM1_Pin GPIO_PIN_7
#define LPWM1_GPIO_Port GPIOA
#define SERVO_Y_Pin GPIO_PIN_0
#define SERVO_Y_GPIO_Port GPIOB
#define LEN1_Pin GPIO_PIN_1
#define LEN1_GPIO_Port GPIOB
#define REN2_Pin GPIO_PIN_2
#define REN2_GPIO_Port GPIOB
#define LEN2_Pin GPIO_PIN_10
#define LEN2_GPIO_Port GPIOB
#define IMU_I2C_SCL_Pin GPIO_PIN_8
#define IMU_I2C_SCL_GPIO_Port GPIOA
#define LIDAR_PWM_Pin GPIO_PIN_9
#define LIDAR_PWM_GPIO_Port GPIOA
#define SERVO_X_Pin GPIO_PIN_10
#define SERVO_X_GPIO_Port GPIOA
#define LIDAR_TX_Pin GPIO_PIN_11
#define LIDAR_TX_GPIO_Port GPIOA
#define LIDAR_RX_Pin GPIO_PIN_12
#define LIDAR_RX_GPIO_Port GPIOA
#define B1_Pin GPIO_PIN_3
#define B1_GPIO_Port GPIOB
#define IMU_I2C_SDA_Pin GPIO_PIN_4
#define IMU_I2C_SDA_GPIO_Port GPIOB
#define RPWM2_Pin GPIO_PIN_6
#define RPWM2_GPIO_Port GPIOB
#define LPWM2_Pin GPIO_PIN_7
#define LPWM2_GPIO_Port GPIOB
#define ESP_I2C_SCL_Pin GPIO_PIN_8
#define ESP_I2C_SCL_GPIO_Port GPIOB
#define ESP_I2C_SDA_Pin GPIO_PIN_9
#define ESP_I2C_SDA_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
