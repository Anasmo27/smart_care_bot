/*
 * motion.h
 *
 *  Created on: Mar 13, 2026
 *      Author: ASUS
 */

#ifndef INC_MOTION_H_
#define INC_MOTION_H_



#include "main.h"
#include "bts7960.h"
#include "encoder.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum
{
    MOTION_IDLE = 0,
    MOTION_RAMP_UP,
    MOTION_CRUISE,
    MOTION_RAMP_DOWN,
    MOTION_DONE
} motion_state_t;

typedef struct
{
    bts7960_t *motor;
    encoder_t *encoder;

    motion_state_t state;

    int32_t start_count;
    int32_t target_counts;     // absolute move distance in counts
    int32_t brake_counts;      // when remain <= brake_counts => start ramp down

    int8_t direction;          // +1 forward, -1 backward

    int16_t max_pwm;           // requested max speed
    int16_t min_pwm;           // minimum useful pwm while moving
    int16_t current_cmd;       // signed current target command

    uint8_t active;

    /* advanced motion path (new API, legacy path remains untouched) */
    uint8_t adv_enabled;
    int32_t adv_accel_counts;
    int32_t adv_stop_deadband;
    int16_t adv_brake_min_pwm;
    int16_t adv_last_pwm_mag;

    uint32_t start_tick;
    uint32_t timeout_ms;
} motion_t;

void motion_init(motion_t *m, bts7960_t *motor, encoder_t *encoder);
void motion_start(motion_t *m, int8_t direction, int32_t steps, int16_t speed_pwm);
void motion_stop(motion_t *m);
void motion_update(motion_t *m);

motion_state_t motion_get_state(motion_t *m);
int32_t motion_get_travelled(motion_t *m);
int32_t motion_get_remaining(motion_t *m);


/* Advanced API (added without removing legacy API) */
void motion_config_adv(motion_t *m, int32_t accel_counts, int32_t stop_deadband, int16_t brake_min_pwm);
void motion_start_adv(motion_t *m, int8_t direction, int32_t steps, int16_t speed_pwm);
void motion_start_distance_cm(motion_t *m, int8_t direction, float distance_cm, int16_t speed_pwm, float ticks_per_cm);
void motion_update_adv(motion_t *m);

#ifdef __cplusplus
}
#endif




#endif /* INC_MOTION_H_ */
