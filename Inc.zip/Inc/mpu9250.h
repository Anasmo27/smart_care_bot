/*
 * mpu9250.h
 *
 *  Created on: Apr 10, 2026
 *      Author: ASUS
 */

#ifndef INC_MPU9250_H_
#define INC_MPU9250_H_

#include "main.h"
#include <stdint.h>

#define MPU9250_I2C_ADDR        (0x68 << 1)
#define AK8963_I2C_ADDR         (0x0C << 1)

// MPU9250 registers
#define MPU9250_WHO_AM_I        0x75
#define MPU9250_PWR_MGMT_1      0x6B
#define MPU9250_INT_PIN_CFG     0x37
#define MPU9250_ACCEL_XOUT_H    0x3B
#define MPU9250_GYRO_CONFIG     0x1B
#define MPU9250_ACCEL_CONFIG    0x1C

// AK8963 registers
#define AK8963_WHO_AM_I         0x00
#define AK8963_ST1              0x02
#define AK8963_XOUT_L           0x03
#define AK8963_ST2              0x09
#define AK8963_CNTL1            0x0A
#define AK8963_CNTL2            0x0B

typedef struct
{
    int16_t ax;
    int16_t ay;
    int16_t az;

    int16_t gx;
    int16_t gy;
    int16_t gz;

    int16_t mx;
    int16_t my;
    int16_t mz;

    float ax_g;
    float ay_g;
    float az_g;

    float gx_dps;
    float gy_dps;
    float gz_dps;

    float heading_deg;
    float yaw_gyro;
    float yaw_fused;

    float gz_bias;

    float mag_offset_x;
    float mag_offset_y;
    float mag_offset_z;

    uint8_t mpu_ok;
    uint8_t mag_ok;

    uint32_t last_tick_ms;
} mpu9250_t;

HAL_StatusTypeDef mpu9250_init(mpu9250_t *imu, I2C_HandleTypeDef *hi2c);
HAL_StatusTypeDef mpu9250_read_accel_gyro(mpu9250_t *imu, I2C_HandleTypeDef *hi2c);
HAL_StatusTypeDef mpu9250_read_mag(mpu9250_t *imu, I2C_HandleTypeDef *hi2c);
HAL_StatusTypeDef mpu9250_update(mpu9250_t *imu, I2C_HandleTypeDef *hi2c, uint32_t now_ms);
HAL_StatusTypeDef mpu9250_calibrate_gyro_z(mpu9250_t *imu, I2C_HandleTypeDef *hi2c, uint16_t samples);
float mpu9250_wrap360(float angle);


#endif /* INC_MPU9250_H_ */
