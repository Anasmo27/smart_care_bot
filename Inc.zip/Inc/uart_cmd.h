/*
 * uart_cmd.h
 *
 *  Created on: Mar 9, 2026
 *      Author: ASUS
 */

#ifndef INC_UART_CMD_H_
#define INC_UART_CMD_H_

#include "main.h"
#include "motion.h"
#include "encoder.h"
#include "curve.h"
#include <stdint.h>

void uart_cmd_init(UART_HandleTypeDef *huart,
                   motion_t *mv1, motion_t *mv2,
                   encoder_t *e1, encoder_t *e2,
                   curve_t *cv);

void uart_cmd_rx_byte(uint8_t byte);
void uart_cmd_task(void);



#endif /* INC_UART_CMD_H_ */
