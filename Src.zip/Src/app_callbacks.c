#include "app_callbacks.h"
#include "app_i2c_proto.h"
#include "uart_cmd.h"
#include <string.h>

extern UART_HandleTypeDef huart2;
extern I2C_HandleTypeDef hi2c1;
extern uint8_t rxByte;

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART2)
    {
        uart_cmd_rx_byte(rxByte);
        HAL_UART_Receive_IT(&huart2, &rxByte, 1);
    }
}

void HAL_I2C_AddrCallback(I2C_HandleTypeDef *hi2c,
                          uint8_t TransferDirection,
                          uint16_t AddrMatchCode)
{
    (void)AddrMatchCode;

    if (hi2c->Instance != I2C1)
    {
        return;
    }

    if (TransferDirection == I2C_DIRECTION_TRANSMIT)
    {
        memset(i2c_rx_buf, 0, sizeof(i2c_rx_buf));
        i2c_rx_stage = 1;
        i2c_expected_len = 0;

        HAL_I2C_Slave_Seq_Receive_IT(&hi2c1,
                                     i2c_rx_buf,
                                     I2C_CMD_HEADER_LEN,
                                     I2C_FIRST_FRAME);
    }
    else
    {
        if (i2c_tx_len == 0U)
        {
            app_i2c_build_default_response();
        }

        HAL_I2C_Slave_Seq_Transmit_IT(&hi2c1,
                                      i2c_tx_buf,
                                      i2c_tx_len,
                                      I2C_FIRST_AND_LAST_FRAME);
    }
}

void HAL_I2C_SlaveRxCpltCallback(I2C_HandleTypeDef *hi2c)
{
    uint8_t i;

    if (hi2c->Instance != I2C1)
    {
        return;
    }

    if (i2c_rx_stage == 1U)
    {
        uint8_t len = i2c_rx_buf[5];

        if ((uint16_t)(7U + len) > I2C_RX_MAX)
        {
            i2c_rx_stage = 0;
            app_i2c_build_error_response(0, 0, RESP_BAD_LEN);
            return;
        }

        i2c_expected_len = (uint8_t)(7U + len);
        i2c_rx_stage = 2U;

        HAL_I2C_Slave_Seq_Receive_IT(&hi2c1,
                                     &i2c_rx_buf[6],
                                     (uint16_t)(len + 1U),
                                     I2C_LAST_FRAME);
        return;
    }

    if (i2c_rx_stage == 2U)
    {
        uint32_t primask_state;

        i2c_rx_len = i2c_expected_len;
        i2c_rx_stage = 0U;

        primask_state = __get_PRIMASK();
        __disable_irq();

        for (i = 0U; i < i2c_rx_len; i++)
        {
            i2c_rx_shadow[i] = i2c_rx_buf[i];
        }

        i2c_shadow_len = i2c_rx_len;
        i2c_shadow_ready = 1U;
        i2c_frame_ready = 1U;

        if ((primask_state & 1U) == 0U)
        {
            __enable_irq();
        }

        dbg_i2c_rx_done = 1U;
    }
}

void HAL_I2C_SlaveTxCpltCallback(I2C_HandleTypeDef *hi2c)
{
    if (hi2c->Instance != I2C1)
    {
        return;
    }

    dbg_i2c_tx_done = 1U;
}

void HAL_I2C_ListenCpltCallback(I2C_HandleTypeDef *hi2c)
{
    if (hi2c->Instance != I2C1)
    {
        return;
    }

    HAL_I2C_EnableListen_IT(&hi2c1);
}

void HAL_I2C_ErrorCallback(I2C_HandleTypeDef *hi2c)
{
    if (hi2c->Instance != I2C1)
    {
        return;
    }

    // --- التعديل الجوهري: تحرير الخط فوراً عند حدوث خطأ ---
    i2c_rx_stage = 0;
    i2c_error_flag = 1;
    i2c_fault_flags |= FAULT_I2C_ERROR;
    dbg_i2c_error_seen = 1;

    // إرسال Stop Condition برمجي لإرغام الـ Bus على التحرر
    SET_BIT(hi2c->Instance->CR1, I2C_CR1_STOP);

    // إعادة تفعيل الاستماع للمرة القادمة
    HAL_I2C_EnableListen_IT(&hi2c1);
}
