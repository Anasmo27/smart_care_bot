#include "app_i2c_proto.h"
#include <stdio.h>
#include <string.h>

#define DEBUG_UART_ENABLE  0

#if DEBUG_UART_ENABLE
#define DBG_UART_TX(buf, len) HAL_UART_Transmit(&huart2, (uint8_t*)(buf), (len), 100)
#else
#define DBG_UART_TX(buf, len) ((void)0)
#endif

static uint8_t frame_xor(const uint8_t *data, uint8_t len);
static void build_response(uint8_t seq, uint8_t cmd, uint8_t status,
                           const uint8_t *payload, uint8_t payload_len);

static void execute_command(uint8_t seq, uint8_t cmd,
                            const uint8_t *payload, uint8_t payload_len);

static void stop_all_local(void);
static void car_move_same_local(int8_t dir, int32_t steps, int16_t speed);
static void car_turn_in_place_right_local(int32_t steps, int16_t speed);
static void car_turn_in_place_left_local(int32_t steps, int16_t speed);
static void car_curve_forward_right_local(int32_t steps, int16_t speed);
static void car_curve_forward_left_local(int32_t steps, int16_t speed);
static void car_curve_backward_right_local(int32_t steps, int16_t speed);
static void car_curve_backward_left_local(int32_t steps, int16_t speed);
static void car_move_distance_local(int8_t dir, float distance_cm, int16_t speed);

static int16_t get_encoder16(encoder_t *enc);
static uint8_t get_motion_active(const motion_t *mv);
static uint8_t get_curve_active(const curve_t *cv);

static void build_motion_state_payload(uint8_t *payload, uint8_t *payload_len);
static void build_encoders_payload(uint8_t *payload, uint8_t *payload_len);
static void build_faults_payload(uint8_t *payload, uint8_t *payload_len);
static void build_odom_payload(uint8_t *payload, uint8_t *payload_len);

static void pack_i16_be(uint8_t *buf, uint8_t *idx, int16_t value);
static int16_t float_to_i16_scaled(float value, float scale);

static HAL_StatusTypeDef imu_collect_average(uint8_t samples, uint16_t delay_ms, imu_avg_t *avg);
static void build_imu_raw_avg_payload(uint8_t *payload, uint8_t *payload_len, const imu_avg_t *avg);
static void build_imu_yaw_avg_payload(uint8_t *payload, uint8_t *payload_len, const imu_avg_t *avg);

static void robot_set_mode(robot_mode_t mode);
static void robot_set_stop_reason(stop_reason_t reason);
static void robot_set_idle_if_stopped(void);
static uint8_t system_motion_busy_local(void);
static void clear_watchdog_fault_local(uint32_t now);
static float turn_get_start_yaw_avg(void);

typedef struct
{
    uint8_t active;
    uint8_t started;
    int8_t dir;              /* +1 right, -1 left */
    float start_yaw_deg;
    float target_deg;
    uint32_t start_tick;
    int16_t speed;           /* Tracks dynamic speed requested by ESP32 */
} turn_ctrl_t;

static turn_ctrl_t g_turn = {0};
static uint8_t wd_timeout_reported = 0;

volatile robot_mode_t g_robot_mode = ROBOT_MODE_IDLE;
volatile stop_reason_t g_stop_reason = STOP_REASON_NONE;

static void robot_set_mode(robot_mode_t mode)
{
    g_robot_mode = mode;
}

static void robot_set_stop_reason(stop_reason_t reason)
{
    g_stop_reason = reason;
}

static void robot_set_idle_if_stopped(void)
{
    if ((MV1.active == 0U) && (MV2.active == 0U) && (CV.active == 0U) && (g_turn.active == 0U))
    {
        robot_set_mode(ROBOT_MODE_IDLE);
    }
}

static uint8_t system_motion_busy_local(void)
{
    return (uint8_t)(((MV1.active != 0U) ||
                      (MV2.active != 0U) ||
                      (CV.active != 0U) ||
                      (g_turn.active != 0U)) ? 1U : 0U);
}

static void clear_watchdog_fault_local(uint32_t now)
{
    i2c_watchdog_counter = 0U;
    last_i2c_cmd_tick = now;
    last_watchdog_tick = now;
    wd_timeout_reported = 0U;
    i2c_fault_flags &= (uint8_t)(~FAULT_I2C_ERROR);
    i2c_system_ok = (i2c_fault_flags == FAULT_NONE) ? 1U : 0U;

    if ((g_stop_reason == STOP_REASON_WATCHDOG) && (system_motion_busy_local() == 0U))
    {
        robot_set_mode(ROBOT_MODE_IDLE);
        robot_set_stop_reason(STOP_REASON_NONE);
    }
}

static void turn_force_stop_outputs(void)
{
    bts_set_target_pwm(&M1, 0);
    bts_set_target_pwm(&M2, 0);
}

static float turn_get_start_yaw_avg(void)
{
    return IMU.yaw_gyro;
}

static float angle_diff_deg(float a, float b)
{
    float d = a - b;
    while (d > 180.0f) d -= 360.0f;
    while (d < -180.0f) d += 360.0f;
    return d;
}

static void turn_stop_local(void)
{
    g_turn.active = 0U;
    g_turn.started = 0U;
    turn_force_stop_outputs();
    robot_set_idle_if_stopped();
}

static void turn_start_local(int8_t dir, float angle_deg, int16_t speed)
{
    g_turn.active = 0U;
    g_turn.started = 0U;
    stop_all_local();
    turn_force_stop_outputs();

    g_turn.active = 1U;
    g_turn.started = 0U;
    g_turn.dir = (dir >= 0) ? +1 : -1;
    g_turn.start_yaw_deg = turn_get_start_yaw_avg();

    g_turn.target_deg = angle_deg * TURN_CTRL_ANGLE_CMD_SCALE;
    if (g_turn.target_deg < 1.0f) {
        g_turn.target_deg = 1.0f;
    }

    g_turn.start_tick = HAL_GetTick();
    g_turn.speed = speed;

    robot_set_mode(ROBOT_MODE_TURN);
    robot_set_stop_reason(STOP_REASON_NONE);

    if (g_turn.dir > 0)
    {
        bts_set_target_pwm(&M1, -g_turn.speed);
        bts_set_target_pwm(&M2, +g_turn.speed);
    }
    else
    {
        bts_set_target_pwm(&M1, +g_turn.speed);
        bts_set_target_pwm(&M2, -g_turn.speed);
    }
}

void app_i2c_slave_start_listen(void)
{
    if (HAL_I2C_EnableListen_IT(&hi2c1) != HAL_OK)
    {
        i2c_fault_flags |= FAULT_I2C_ERROR;
        i2c_error_flag = 1;
    }
}

void app_i2c_build_default_response(void)
{
    build_response(0x00, 0x00, RESP_BAD_FRAME, NULL, 0);
}

void app_i2c_build_error_response(uint8_t seq, uint8_t cmd, uint8_t status)
{
    build_response(seq, cmd, status, NULL, 0);
}

void app_i2c_print_error(void)
{
    char msg[64];
    uint32_t err = HAL_I2C_GetError(&hi2c1);
    snprintf(msg, sizeof(msg), "I2C ERROR: 0x%08lX\r\n", err);
    HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);
}

void app_i2c_update_system_status(void)
{
    uint32_t now = HAL_GetTick();
    uint32_t elapsed_ms = now - last_i2c_cmd_tick;
    uint32_t wd_count = elapsed_ms / 1000U;
    uint8_t motion_busy = system_motion_busy_local();

    last_watchdog_tick = now;

    if (wd_count > 255U)
    {
        wd_count = 255U;
    }
    i2c_watchdog_counter = (uint8_t)wd_count;

    if ((!motion_busy) && (elapsed_ms > I2C_WD_TIMEOUT_MS))
    {
        if ((g_robot_mode != ROBOT_MODE_FAULT) || (g_stop_reason != STOP_REASON_WATCHDOG))
        {
            stop_all_local();
            robot_set_mode(ROBOT_MODE_FAULT);
            robot_set_stop_reason(STOP_REASON_WATCHDOG);
        }

        i2c_fault_flags |= FAULT_I2C_ERROR;

        if (!wd_timeout_reported)
        {
#if DEBUG_UART_ENABLE
            const char *msg = "WATCHDOG TIMEOUT -> STOP\r\n";
            DBG_UART_TX(msg, strlen(msg));
#endif
            wd_timeout_reported = 1U;
        }
    }

    i2c_system_ok = (i2c_fault_flags == FAULT_NONE) ? 1U : 0U;
}

static uint8_t frame_xor(const uint8_t *data, uint8_t len)
{
    uint8_t x = 0;
    uint8_t i = 0;

    for (i = 0; i < len; i++)
    {
        x ^= data[i];
    }
    return x;
}

static int16_t float_to_i16_scaled(float value, float scale)
{
    float scaled = value * scale;

    if (scaled > 32767.0f)
    {
        scaled = 32767.0f;
    }
    else if (scaled < -32768.0f)
    {
        scaled = -32768.0f;
    }

    return (int16_t)scaled;
}

static void pack_i16_be(uint8_t *buf, uint8_t *idx, int16_t value)
{
    buf[*idx] = (uint8_t)((value >> 8) & 0xFF);
    (*idx)++;
    buf[*idx] = (uint8_t)(value & 0xFF);
    (*idx)++;
}

static void build_response(uint8_t seq, uint8_t cmd, uint8_t status,
                           const uint8_t *payload, uint8_t payload_len)
{
    uint8_t idx = 0;
    uint8_t chk = 0;
    uint8_t i = 0;

    if ((uint16_t)payload_len + I2C_RESP_OVERHEAD > I2C_TX_MAX)
    {
        payload = NULL;
        payload_len = 0;
        status = RESP_BAD_LEN;
    }

    i2c_tx_buf[idx++] = FRAME_SOF1;
    i2c_tx_buf[idx++] = FRAME_SOF2;
    i2c_tx_buf[idx++] = PKT_TYPE_RESP;
    i2c_tx_buf[idx++] = seq;
    i2c_tx_buf[idx++] = cmd;
    i2c_tx_buf[idx++] = status;
    i2c_tx_buf[idx++] = payload_len;

    for (i = 0; i < payload_len; i++)
    {
        i2c_tx_buf[idx++] = payload[i];
    }

    chk = frame_xor(i2c_tx_buf, idx);
    i2c_tx_buf[idx++] = chk;
    i2c_tx_len = idx;
}

static void stop_all_local(void)
{
    curve_stop(&CV);
    motion_stop(&MV1);
    motion_stop(&MV2);
    turn_stop_local();
    robot_set_mode(ROBOT_MODE_IDLE);
}

static void car_move_same_local(int8_t dir, int32_t steps, int16_t speed)
{
    curve_stop(&CV);

    encoder_reset(&ENC1);
    encoder_reset(&ENC2);

    motion_start(&MV1, -dir, steps, speed);
    motion_start(&MV2, -dir, steps, speed);

    robot_set_mode(ROBOT_MODE_STRAIGHT);
    robot_set_stop_reason(STOP_REASON_NONE);
}

static void car_turn_in_place_right_local(int32_t steps, int16_t speed)
{
    curve_stop(&CV);

    encoder_reset(&ENC1);
    encoder_reset(&ENC2);

    motion_start(&MV1, +1, steps, speed);
    motion_start(&MV2, -1, steps, speed);

    robot_set_mode(ROBOT_MODE_TURN);
    robot_set_stop_reason(STOP_REASON_NONE);
}

static void car_turn_in_place_left_local(int32_t steps, int16_t speed)
{
    curve_stop(&CV);

    encoder_reset(&ENC1);
    encoder_reset(&ENC2);

    motion_start(&MV1, -1, steps, speed);
    motion_start(&MV2, +1, steps, speed);

    robot_set_mode(ROBOT_MODE_TURN);
    robot_set_stop_reason(STOP_REASON_NONE);
}

static void car_curve_forward_right_local(int32_t steps, int16_t speed)
{
    stop_all_local();
    encoder_reset(&ENC1);
    encoder_reset(&ENC2);

    curve_start(&CV,
                MV2.motor, &ENC2, -1,
                MV1.motor, &ENC1, -1,
                steps, speed,
                60, 100);

    robot_set_mode(ROBOT_MODE_CURVE);
    robot_set_stop_reason(STOP_REASON_NONE);
}

static void car_curve_forward_left_local(int32_t steps, int16_t speed)
{
    stop_all_local();
    encoder_reset(&ENC1);
    encoder_reset(&ENC2);

    curve_start(&CV,
                MV1.motor, &ENC1, -1,
                MV2.motor, &ENC2, -1,
                steps, speed,
                70, 100);

    robot_set_mode(ROBOT_MODE_CURVE);
    robot_set_stop_reason(STOP_REASON_NONE);
}

static void car_curve_backward_right_local(int32_t steps, int16_t speed)
{
    stop_all_local();
    encoder_reset(&ENC1);
    encoder_reset(&ENC2);

    curve_start(&CV,
                MV2.motor, &ENC2, +1,
                MV1.motor, &ENC1, +1,
                steps, speed,
                60, 100);

    robot_set_mode(ROBOT_MODE_CURVE);
    robot_set_stop_reason(STOP_REASON_NONE);
}

static void car_curve_backward_left_local(int32_t steps, int16_t speed)
{
    stop_all_local();
    encoder_reset(&ENC1);
    encoder_reset(&ENC2);

    curve_start(&CV,
                MV1.motor, &ENC1, +1,
                MV2.motor, &ENC2, +1,
                steps, speed,
                60, 100);

    robot_set_mode(ROBOT_MODE_CURVE);
    robot_set_stop_reason(STOP_REASON_NONE);
}

static void car_move_distance_local(int8_t dir, float distance_cm, int16_t speed)
{
    int8_t motor_dir;
    int16_t applied_speed;

    if (distance_cm <= 0.0f)
        return;

    if (speed < STRAIGHT_SPEED_MIN_CMD)
        applied_speed = STRAIGHT_SPEED_MIN_CMD;
    else if (speed > STRAIGHT_SPEED_MAX_CMD)
        applied_speed = STRAIGHT_SPEED_MAX_CMD;
    else
        applied_speed = speed;

    /* * THE FIX: Feed-Forward Compensation for Inertia/Momentum.
     * Speed 120 undershoots by 0.3 cm -> We add 0.3 to the math.
     * Speed 200 overshoots by 0.7 cm -> We subtract 0.7 from the math.
     * This linear formula magically fixes every speed between 120 and 200!
     */
    float comp_cm = 0.3f - ((float)(applied_speed - 120) * 0.0125f);
    float corrected_distance = distance_cm + comp_cm;

    /* Safety clamp just in case */
    if (corrected_distance < 1.0f) {
        corrected_distance = 1.0f;
    }

    stop_all_local();
    encoder_reset(&ENC1);
    encoder_reset(&ENC2);

    motor_dir = (dir >= 0) ? -1 : +1;

    motion_config_adv(&MV1, DIST_ADV_ACCEL_COUNTS, DIST_ADV_STOP_DEADBAND, DIST_ADV_BRAKE_MIN_PWM);
    motion_config_adv(&MV2, DIST_ADV_ACCEL_COUNTS, DIST_ADV_STOP_DEADBAND, DIST_ADV_BRAKE_MIN_PWM);

    motion_start_distance_cm(&MV1, motor_dir, corrected_distance, applied_speed, ROBOT_TICKS_PER_CM_M1);
    motion_start_distance_cm(&MV2, motor_dir, corrected_distance, applied_speed, ROBOT_TICKS_PER_CM_M2);

    robot_set_mode(ROBOT_MODE_STRAIGHT);
    robot_set_stop_reason(STOP_REASON_NONE);
}

static int16_t get_encoder16(encoder_t *enc)
{
    return (int16_t)encoder_get_count(enc);
}

static uint8_t get_motion_active(const motion_t *mv)
{
    return ((mv->active != 0U) || (g_turn.active != 0U)) ? 1U : 0U;
}

static uint8_t get_curve_active(const curve_t *cv)
{
    return (cv->active != 0U) ? 1U : 0U;
}

static void build_motion_state_payload(uint8_t *payload, uint8_t *payload_len)
{
    int16_t e1 = get_encoder16(&ENC1);
    int16_t e2 = get_encoder16(&ENC2);
    uint8_t idx = 0;

    pack_i16_be(payload, &idx, e1);
    pack_i16_be(payload, &idx, e2);

    payload[idx++] = get_motion_active(&MV1);
    payload[idx++] = get_motion_active(&MV2);
    payload[idx++] = get_curve_active(&CV);

    payload[idx++] = (uint8_t)g_robot_mode;
    payload[idx++] = (uint8_t)g_stop_reason;

    *payload_len = idx;
}

static void build_encoders_payload(uint8_t *payload, uint8_t *payload_len)
{
    int16_t e1 = get_encoder16(&ENC1);
    int16_t e2 = get_encoder16(&ENC2);
    uint8_t idx = 0;

    pack_i16_be(payload, &idx, e1);
    pack_i16_be(payload, &idx, e2);

    *payload_len = idx;
}

static void build_faults_payload(uint8_t *payload, uint8_t *payload_len)
{
    app_i2c_update_system_status();

    payload[0] = i2c_system_ok;
    payload[1] = i2c_fault_flags;
    payload[2] = i2c_watchdog_counter;

    *payload_len = 3;
}

static void build_odom_payload(uint8_t *payload, uint8_t *payload_len)
{
    uint8_t idx = 0;
    int16_t e1 = get_encoder16(&ENC1);
    int16_t e2 = get_encoder16(&ENC2);
    int16_t yaw = float_to_i16_scaled(IMU.yaw_fused, IMU_ANGLE_SCALE_X100);

    pack_i16_be(payload, &idx, e1);
    pack_i16_be(payload, &idx, e2);
    pack_i16_be(payload, &idx, yaw);

    payload[idx++] = get_motion_active(&MV1);
    payload[idx++] = get_motion_active(&MV2);
    payload[idx++] = get_curve_active(&CV);
    payload[idx++] = i2c_system_ok;
    payload[idx++] = i2c_fault_flags;
    payload[idx++] = (uint8_t)g_robot_mode;
    payload[idx++] = (uint8_t)g_stop_reason;

    *payload_len = idx;
}

static HAL_StatusTypeDef imu_collect_average(uint8_t samples, uint16_t delay_ms, imu_avg_t *avg)
{
    uint8_t ok_count = 0;
    uint8_t tries = 0;

    float sum_ax = 0.0f;
    float sum_ay = 0.0f;
    float sum_az = 0.0f;

    float sum_gx = 0.0f;
    float sum_gy = 0.0f;
    float sum_gz = 0.0f;

    int32_t sum_mx = 0;
    int32_t sum_my = 0;
    int32_t sum_mz = 0;

    float sum_heading = 0.0f;
    float sum_yaw_gyro = 0.0f;
    float sum_yaw_fused = 0.0f;

    HAL_StatusTypeDef st;

    if ((avg == NULL) || (samples == 0U) || (imu_ready == 0U))
    {
        return HAL_ERROR;
    }

    memset(avg, 0, sizeof(*avg));

    while ((ok_count < samples) && (tries < IMU_MAX_TRIES))
    {
        tries++;

        st = mpu9250_update(&IMU, &hi2c3, HAL_GetTick());

        if (st == HAL_OK)
        {
            sum_ax += IMU.ax_g;
            sum_ay += IMU.ay_g;
            sum_az += IMU.az_g;

            sum_gx += IMU.gx_dps;
            sum_gy += IMU.gy_dps;
            sum_gz += IMU.gz_dps;

            sum_mx += IMU.mx;
            sum_my += IMU.my;
            sum_mz += IMU.mz;

            sum_heading += IMU.heading_deg;
            sum_yaw_gyro += IMU.yaw_gyro;
            sum_yaw_fused += IMU.yaw_fused;

            ok_count++;
        }
        else if (st != HAL_BUSY)
        {
            i2c_fault_flags |= FAULT_IMU_ERROR;
        }

        HAL_Delay(delay_ms);
    }

    if (ok_count == 0U)
    {
        i2c_fault_flags |= FAULT_IMU_ERROR;
        return HAL_ERROR;
    }

    avg->ax_g = sum_ax / ok_count;
    avg->ay_g = sum_ay / ok_count;
    avg->az_g = sum_az / ok_count;

    avg->gx_dps = sum_gx / ok_count;
    avg->gy_dps = sum_gy / ok_count;
    avg->gz_dps = sum_gz / ok_count;

    avg->mx = (int16_t)(sum_mx / (int32_t)ok_count);
    avg->my = (int16_t)(sum_my / (int32_t)ok_count);
    avg->mz = (int16_t)(sum_mz / (int32_t)ok_count);

    avg->heading_deg = sum_heading / ok_count;
    avg->yaw_gyro = sum_yaw_gyro / ok_count;
    avg->yaw_fused = sum_yaw_fused / ok_count;

    i2c_fault_flags &= (uint8_t)(~FAULT_IMU_ERROR);
    return HAL_OK;
}

static void build_imu_raw_avg_payload(uint8_t *payload, uint8_t *payload_len, const imu_avg_t *avg)
{
    uint8_t idx = 0;

    int16_t ax = float_to_i16_scaled(avg->ax_g, IMU_ACC_SCALE_G_X1000);
    int16_t ay = float_to_i16_scaled(avg->ay_g, IMU_ACC_SCALE_G_X1000);
    int16_t az = float_to_i16_scaled(avg->az_g, IMU_ACC_SCALE_G_X1000);

    int16_t gx = float_to_i16_scaled(avg->gx_dps, IMU_GYRO_SCALE_DPS_X100);
    int16_t gy = float_to_i16_scaled(avg->gy_dps, IMU_GYRO_SCALE_DPS_X100);
    int16_t gz = float_to_i16_scaled(avg->gz_dps, IMU_GYRO_SCALE_DPS_X100);

    pack_i16_be(payload, &idx, ax);
    pack_i16_be(payload, &idx, ay);
    pack_i16_be(payload, &idx, az);
    pack_i16_be(payload, &idx, gx);
    pack_i16_be(payload, &idx, gy);
    pack_i16_be(payload, &idx, gz);
    pack_i16_be(payload, &idx, avg->mx);
    pack_i16_be(payload, &idx, avg->my);
    pack_i16_be(payload, &idx, avg->mz);

    *payload_len = idx;
}

static void build_imu_yaw_avg_payload(uint8_t *payload, uint8_t *payload_len, const imu_avg_t *avg)
{
    uint8_t idx = 0;

    int16_t heading = float_to_i16_scaled(avg->heading_deg, IMU_ANGLE_SCALE_X100);
    int16_t yaw_gyro = float_to_i16_scaled(avg->yaw_gyro, IMU_ANGLE_SCALE_X100);
    int16_t yaw_fused = float_to_i16_scaled(avg->yaw_fused, IMU_ANGLE_SCALE_X100);

    pack_i16_be(payload, &idx, heading);
    pack_i16_be(payload, &idx, yaw_gyro);
    pack_i16_be(payload, &idx, yaw_fused);

    *payload_len = idx;
}

static void execute_command(uint8_t seq, uint8_t cmd,
                            const uint8_t *payload, uint8_t payload_len)
{
    uint8_t resp_payload[80]; // تمت التوسعة لتستوعب الـ Chunk الخاص بالليدار
    uint8_t resp_len = 0;
    imu_avg_t imu_avg;
    HAL_StatusTypeDef imu_st;

    switch (cmd)
    {
        case CMD_LED_ON:
        case CMD_LED_OFF:
            build_response(seq, cmd, RESP_UNKNOWN_CMD, NULL, 0);
            DBG_UART_TX("CMD LED TEST DISABLED\r\n", 23);
            break;

        case CMD_STATUS:
            app_i2c_update_system_status();
            resp_payload[0] = i2c_system_ok;
            resp_payload[1] = i2c_fault_flags;
            resp_payload[2] = i2c_watchdog_counter;
            resp_len = 3;
            build_response(seq, cmd, RESP_OK, resp_payload, resp_len);
            DBG_UART_TX("CMD STATUS\r\n", 12);
            break;

        case CMD_RESET_WD:
            clear_watchdog_fault_local(HAL_GetTick());
            robot_set_mode(ROBOT_MODE_IDLE);
            robot_set_stop_reason(STOP_REASON_NONE);
            build_response(seq, cmd, RESP_OK, NULL, 0);
            DBG_UART_TX("CMD RESET_WD\r\n", 14);
            break;

        case CMD_STOP:
            stop_all_local();
            robot_set_stop_reason(STOP_REASON_MANUAL);
            build_response(seq, cmd, RESP_OK, NULL, 0);
            DBG_UART_TX("CMD STOP\r\n", 10);
            break;

        case CMD_CAR_CTRL:
        {
            uint8_t mode;
            int32_t steps;
            int16_t speed;

            if (payload_len != 4U)
            {
                build_response(seq, cmd, RESP_BAD_LEN, NULL, 0);
                DBG_UART_TX("CMD CAR BAD LEN\r\n", 17);
                break;
            }

            mode  = payload[0];
            steps = ((int32_t)payload[1] << 8) | payload[2];
            speed = (int16_t)payload[3];

            if ((steps <= 0) || (speed <= 0))
            {
                build_response(seq, cmd, RESP_BAD_ARG, NULL, 0);
                DBG_UART_TX("CMD CAR BAD ARG\r\n", 17);
                break;
            }

            switch (mode)
            {
                case CAR_MODE_F:
                    car_move_same_local(+1, steps, speed);
                    DBG_UART_TX("CMD CAR F\r\n", 11);
                    break;

                case CAR_MODE_B:
                    car_move_same_local(-1, steps, speed);
                    DBG_UART_TX("CMD CAR B\r\n", 11);
                    break;

                case CAR_MODE_R:
                    car_turn_in_place_right_local(steps, speed);
                    DBG_UART_TX("CMD CAR R\r\n", 11);
                    break;

                case CAR_MODE_L:
                    car_turn_in_place_left_local(steps, speed);
                    DBG_UART_TX("CMD CAR L\r\n", 11);
                    break;

                case CAR_MODE_FR:
                    car_curve_forward_right_local(steps, speed);
                    DBG_UART_TX("CMD CAR FR\r\n", 12);
                    break;

                case CAR_MODE_FL:
                    car_curve_forward_left_local(steps, speed);
                    DBG_UART_TX("CMD CAR FL\r\n", 12);
                    break;

                case CAR_MODE_BR:
                    car_curve_backward_right_local(steps, speed);
                    DBG_UART_TX("CMD CAR BR\r\n", 12);
                    break;

                case CAR_MODE_BL:
                    car_curve_backward_left_local(steps, speed);
                    DBG_UART_TX("CMD CAR BL\r\n", 12);
                    break;

                default:
                    build_response(seq, cmd, RESP_BAD_ARG, NULL, 0);
                    DBG_UART_TX("CMD CAR BAD MODE\r\n", 18);
                    return;
            }

            build_response(seq, cmd, RESP_OK, NULL, 0);
            break;
        }

        case CMD_GET_MOTION_STATE:
            build_motion_state_payload(resp_payload, &resp_len);
            build_response(seq, cmd, RESP_OK, resp_payload, resp_len);
            DBG_UART_TX("CMD GET_MOTION_STATE\r\n", 22);
            break;

        case CMD_GET_ENCODERS:
            build_encoders_payload(resp_payload, &resp_len);
            build_response(seq, cmd, RESP_OK, resp_payload, resp_len);
            DBG_UART_TX("CMD GET_ENCODERS\r\n", 18);
            break;

        case CMD_GET_FAULTS:
            build_faults_payload(resp_payload, &resp_len);
            build_response(seq, cmd, RESP_OK, resp_payload, resp_len);
            DBG_UART_TX("CMD GET_FAULTS\r\n", 16);
            break;

        case CMD_GET_IMU_RAW:
            imu_st = imu_collect_average(IMU_AVG_SAMPLES, IMU_SAMPLE_DELAY_MS, &imu_avg);
            if (imu_st != HAL_OK)
            {
                build_response(seq, cmd, RESP_BAD_ARG, NULL, 0);
                DBG_UART_TX("CMD GET_IMU_RAW FAIL\r\n", 22);
                break;
            }

            build_imu_raw_avg_payload(resp_payload, &resp_len, &imu_avg);
            build_response(seq, cmd, RESP_OK, resp_payload, resp_len);
            DBG_UART_TX("CMD GET_IMU_RAW AVG\r\n", 21);
            break;

        case CMD_GET_IMU_YAW:
            imu_st = imu_collect_average(IMU_AVG_SAMPLES, IMU_SAMPLE_DELAY_MS, &imu_avg);
            if (imu_st != HAL_OK)
            {
                build_response(seq, cmd, RESP_BAD_ARG, NULL, 0);
                DBG_UART_TX("CMD GET_IMU_YAW FAIL\r\n", 22);
                break;
            }

            build_imu_yaw_avg_payload(resp_payload, &resp_len, &imu_avg);
            build_response(seq, cmd, RESP_OK, resp_payload, resp_len);
            DBG_UART_TX("CMD GET_IMU_YAW AVG\r\n", 21);
            break;

        case CMD_GET_ODOM:
            build_odom_payload(resp_payload, &resp_len);
            build_response(seq, cmd, RESP_OK, resp_payload, resp_len);
            DBG_UART_TX("CMD GET_ODOM\r\n", 14);
            break;

        case CMD_MOVE_CM_FWD:
        case CMD_MOVE_CM_BWD:
        {
            uint16_t dist_x10;
            float distance_cm;
            int16_t speed;
            int8_t dir = (cmd == CMD_MOVE_CM_FWD) ? +1 : -1;

            if (payload_len != 3U)
            {
                build_response(seq, cmd, RESP_BAD_LEN, NULL, 0);
                DBG_UART_TX("CMD MOVE_CM BAD LEN\r\n", 21);
                break;
            }

            dist_x10 = (uint16_t)(((uint16_t)payload[0] << 8) | payload[1]);
            speed = (int16_t)payload[2];
            distance_cm = ((float)dist_x10) / 10.0f;

            if ((distance_cm <= 0.0f) || (speed <= 0))
            {
                build_response(seq, cmd, RESP_BAD_ARG, NULL, 0);
                DBG_UART_TX("CMD MOVE_CM BAD ARG\r\n", 21);
                break;
            }

            car_move_distance_local(dir, distance_cm, speed);
            build_response(seq, cmd, RESP_OK, NULL, 0);
            DBG_UART_TX("CMD MOVE_CM\r\n", 13);
            break;
        }

        case CMD_TURN_DEG_R:
        case CMD_TURN_DEG_L:
        {
            uint16_t deg_x10;
            float angle_deg;
            int16_t speed;
            int8_t dir = (cmd == CMD_TURN_DEG_R) ? -1 : +1;

            if (payload_len != 3U)
            {
                build_response(seq, cmd, RESP_BAD_LEN, NULL, 0);
                DBG_UART_TX("CMD TURN BAD LEN\r\n", 18);
                break;
            }

            deg_x10 = (uint16_t)(((uint16_t)payload[0] << 8) | payload[1]);
            speed = (int16_t)payload[2];
            angle_deg = ((float)deg_x10) / 10.0f;

            if ((angle_deg <= 0.0f) || (speed <= 0))
            {
                build_response(seq, cmd, RESP_BAD_ARG, NULL, 0);
                DBG_UART_TX("CMD TURN BAD ARG\r\n", 18);
                break;
            }

            turn_start_local(dir, angle_deg, speed);
            build_response(seq, cmd, RESP_OK, NULL, 0);
            DBG_UART_TX("CMD TURN_DEG\r\n", 14);
            break;
        }

        // ====================================================================
        // === أوامر الليدار الجديدة للرد على ESP32 ===
        // ====================================================================

        case CMD_LIDAR_INFO:
        {
            // يطلب معلومات عن المسحة الحالية (Latest Scan)
            uint16_t total_points = current_scan.point_count;
            // حساب عدد الـ Chunks اللازمة (كل Chunk فيه 16 نقطة)
            uint16_t chunk_count = (total_points + 15) / 16;

            resp_payload[0] = (uint8_t)(current_scan.scan_id >> 8);
            resp_payload[1] = (uint8_t)(current_scan.scan_id & 0xFF);
            resp_payload[2] = (uint8_t)(total_points >> 8);
            resp_payload[3] = (uint8_t)(total_points & 0xFF);
            resp_payload[4] = (uint8_t)(chunk_count >> 8);
            resp_payload[5] = (uint8_t)(chunk_count & 0xFF);

            resp_len = 6;
            build_response(seq, cmd, RESP_OK, resp_payload, resp_len);
            break;
        }

        case CMD_LIDAR_CHUNK:
        {
            // يطلب جزء محدد (Chunk) من المسحة
            if (payload_len != 3U)
            {
                build_response(seq, cmd, RESP_BAD_LEN, NULL, 0);
                break;
            }

            uint16_t requested_scan_id = (payload[0] << 8) | payload[1];
            uint8_t chunk_index = payload[2];

            // التأكد من أن הـ ESP32 يطلب من المسحة الحالية لتجنب خلط البيانات
            if (requested_scan_id != current_scan.scan_id)
            {
                build_response(seq, cmd, RESP_BAD_ARG, NULL, 0); // المسحة تغيرت
                break;
            }

            uint16_t start_point = chunk_index * 16;
            uint16_t points_to_send = 0;

            if (start_point < current_scan.point_count) {
                points_to_send = current_scan.point_count - start_point;
                if (points_to_send > 16) points_to_send = 16;
            }

            resp_payload[0] = chunk_index;
            resp_payload[1] = points_to_send;
            resp_len = 2;

            for (uint16_t p = 0; p < points_to_send; p++)
            {
                uint16_t angle = current_scan.points[start_point + p].angle_deg_x100;
                uint16_t dist  = current_scan.points[start_point + p].distance_mm;

                resp_payload[resp_len++] = (uint8_t)(angle >> 8);
                resp_payload[resp_len++] = (uint8_t)(angle & 0xFF);
                resp_payload[resp_len++] = (uint8_t)(dist >> 8);
                resp_payload[resp_len++] = (uint8_t)(dist & 0xFF);
            }

            build_response(seq, cmd, RESP_OK, resp_payload, resp_len);
            break;
        }

        case CMD_LIDAR_STATUS:
        {
            // يطلب حالة الليدار
            resp_payload[0] = 1; // متصل (Connected) - يمكنك ربطها بمؤشر القراءة
            resp_payload[1] = 0; // Flags أو أخطاء
            resp_len = 2;
            build_response(seq, cmd, RESP_OK, resp_payload, resp_len);
            break;
        }

        // ====================================================================

        default:
            build_response(seq, cmd, RESP_UNKNOWN_CMD, NULL, 0);
            DBG_UART_TX("CMD UNKNOWN\r\n", 13);
            break;
    }
}

void app_i2c_process_frame(void)
{
    uint8_t pkt_type;
    uint8_t seq;
    uint8_t cmd;
    uint8_t len;
    uint8_t calc_chk;
    uint8_t recv_chk;
    uint8_t local_frame[I2C_RX_MAX];
    uint8_t local_len;
    uint8_t i;
    uint32_t primask_state;

    if (i2c_shadow_ready == 0U)
    {
        return;
    }

    primask_state = __get_PRIMASK();
    __disable_irq();

    i2c_shadow_ready = 0U;
    local_len = i2c_shadow_len;
    for (i = 0U; i < local_len; i++)
    {
        local_frame[i] = i2c_rx_shadow[i];
    }

    if ((primask_state & 1U) == 0U)
    {
        __enable_irq();
    }

    if (local_len < I2C_CMD_MIN_FRAME_LEN)
    {
        build_response(0, 0, RESP_BAD_FRAME, NULL, 0);
        return;
    }

    if ((local_frame[0] != FRAME_SOF1) || (local_frame[1] != FRAME_SOF2))
    {
        build_response(0, 0, RESP_BAD_FRAME, NULL, 0);
        return;
    }

    pkt_type = local_frame[2];
    seq      = local_frame[3];
    cmd      = local_frame[4];
    len      = local_frame[5];

    if (pkt_type != PKT_TYPE_CMD)
    {
        build_response(seq, cmd, RESP_BAD_FRAME, NULL, 0);
        return;
    }

    if (local_len != (uint8_t)(7U + len))
    {
        build_response(seq, cmd, RESP_BAD_LEN, NULL, 0);
        return;
    }

    calc_chk = frame_xor(local_frame, (uint8_t)(local_len - 1U));
    recv_chk = local_frame[local_len - 1U];

    if (calc_chk != recv_chk)
    {
        build_response(seq, cmd, RESP_BAD_CHECKSUM, NULL, 0);
        return;
    }

    clear_watchdog_fault_local(HAL_GetTick());
    execute_command(seq, cmd, &local_frame[6], len);
}

uint8_t app_turn_is_active(void)
{
    return (g_turn.active != 0U) ? 1U : 0U;
}

void app_turn_update(void)
{
    float turned_deg;
    float remain_deg;
    int16_t pwm;
    HAL_StatusTypeDef st;

    if (g_turn.active == 0U)
    {
        return;
    }

    st = mpu9250_update(&IMU, &hi2c3, HAL_GetTick());
    if ((st != HAL_OK) && (st != HAL_BUSY))
    {
        robot_set_mode(ROBOT_MODE_FAULT);
        robot_set_stop_reason(STOP_REASON_FAULT);
        turn_stop_local();
        return;
    }

    turned_deg = angle_diff_deg(IMU.yaw_gyro, g_turn.start_yaw_deg);

    if (turned_deg < 0.0f) {
        turned_deg = -turned_deg;
    }

    remain_deg = g_turn.target_deg - turned_deg;

    if ((g_turn.started == 0U) && (turned_deg >= TURN_CTRL_START_DETECT_DEG))
    {
        g_turn.started = 1U;
    }

    if ((HAL_GetTick() - g_turn.start_tick) >= TURN_CTRL_STARTUP_GUARD_MS)
    {
        if ((HAL_GetTick() - g_turn.start_tick) >= TURN_CTRL_TIMEOUT_MS)
        {
            robot_set_stop_reason(STOP_REASON_TIMEOUT);
            turn_stop_local();
            return;
        }

        if ((g_turn.started != 0U) && (remain_deg <= TURN_CTRL_TOLERANCE_DEG))
        {
            robot_set_stop_reason(STOP_REASON_TARGET_REACHED);
            turn_stop_local();
            return;
        }
    }

    pwm = g_turn.speed;

    if (remain_deg <= TURN_CTRL_SLOW_WINDOW_DEG)
    {
        float scale = remain_deg / TURN_CTRL_SLOW_WINDOW_DEG;
        if (scale < 0.0f) scale = 0.0f;
        if (scale > 1.0f) scale = 1.0f;

        pwm = (int16_t)(TURN_CTRL_MIN_PWM +
               (float)(g_turn.speed - TURN_CTRL_MIN_PWM) * scale);

        if (pwm < TURN_CTRL_MIN_PWM) {
            pwm = TURN_CTRL_MIN_PWM;
        }
        if (pwm > g_turn.speed) {
            pwm = g_turn.speed;
        }
    }

    if (g_turn.dir > 0)
    {
        bts_set_target_pwm(&M1, -pwm);
        bts_set_target_pwm(&M2, +pwm);
    }
    else
    {
        bts_set_target_pwm(&M1, +pwm);
        bts_set_target_pwm(&M2, -pwm);
    }
}

/* ========================================================================= */
/* THE FIX: ENCODER BALANCING CONTROLLER                                     */
/* ========================================================================= */
void app_straight_balance_update(void)
{
    int32_t t1, t2, r1, r2, diff, trim;
    int16_t base1, base2, abs1, abs2;
    int8_t dir;

    // Only balance if we are moving straight and both motors are active
    if (g_robot_mode != ROBOT_MODE_STRAIGHT) return;
    if (MV1.active == 0 || MV2.active == 0) return;

    t1 = motion_get_travelled(&MV1);
    t2 = motion_get_travelled(&MV2);
    r1 = motion_get_remaining(&MV1);
    r2 = motion_get_remaining(&MV2);

    // Give it a chance to start up before fighting, and don't fight while braking heavily
    if (t1 < DIST_BAL_START_ENABLE_TICKS || t2 < DIST_BAL_START_ENABLE_TICKS) return;
    if (r1 < DIST_BAL_NEAR_END_DISABLE || r2 < DIST_BAL_NEAR_END_DISABLE) return;

    // diff is positive if M1 (Right) has travelled further than M2 (Left)
    diff = t1 - t2;

    // Deadband: If the error is tiny, ignore it
    if ((diff > -DIST_BAL_DIFF_DEADBAND_TICKS) && (diff < DIST_BAL_DIFF_DEADBAND_TICKS)) return;

    // Calculate trim (Proportional Controller)
    trim = diff / DIST_BAL_TRIM_DIVISOR;

    // Add extra gain if we are moving slowly
    if (MV1.max_pwm < DIST_BAL_LOW_SPEED_THRESHOLD) {
        trim = (trim * (int32_t)DIST_BAL_LOW_SPEED_GAIN_PCT) / 100;
    }

    // Clamp the maximum power we can add/subtract to maintain balance
    if (trim > DIST_BAL_MAX_TRIM_PWM) trim = DIST_BAL_MAX_TRIM_PWM;
    if (trim < -DIST_BAL_MAX_TRIM_PWM) trim = -DIST_BAL_MAX_TRIM_PWM;

    base1 = MV1.current_cmd;
    base2 = MV2.current_cmd;
    dir = MV1.direction; // 1 for forward, -1 for backward

    abs1 = (base1 >= 0) ? base1 : -base1;
    abs2 = (base2 >= 0) ? base2 : -base2;

    // M1 is ahead -> Trim is positive -> Slow down M1, speed up M2
    abs1 -= trim;
    abs2 += trim;

    // Safety clamps
    if (abs1 < 0) abs1 = 0;
    if (abs2 < 0) abs2 = 0;
    if (abs1 > 255) abs1 = 255;
    if (abs2 > 255) abs2 = 255;

    bts_set_target_pwm(MV1.motor, dir * abs1);
    bts_set_target_pwm(MV2.motor, dir * abs2);
}
