/*
 * bts7960.c
 *
 *  Created on: Mar 6, 2026
 *      Author: ASUS
 */

// Core/Src/bts7960.c
#include "bts7960.h"

static inline int16_t clamp_i16(int16_t v, int16_t lo, int16_t hi) {
  if (v < lo) return lo;
  if (v > hi) return hi;
  return v;
}

static inline uint16_t pwm255_to_ccr(uint16_t period, int16_t pwm_abs_0_255) {
  if (pwm_abs_0_255 <= 0) return 0;
  if (pwm_abs_0_255 >= 255) return period;
  return (uint16_t)((uint32_t)pwm_abs_0_255 * (uint32_t)period / 255U);
}

static inline void set_ccr(TIM_HandleTypeDef *htim, uint32_t ch, uint16_t ccr) {
  __HAL_TIM_SET_COMPARE(htim, ch, ccr);
}

static inline void en_write(GPIO_TypeDef *port, uint16_t pin, GPIO_PinState st) {
  if (port && pin) HAL_GPIO_WritePin(port, pin, st);
}

static void apply_pwm_raw(bts7960_t *m, int16_t pwm_signed_255) {
  pwm_signed_255 = clamp_i16(pwm_signed_255, -255, 255);

  if (pwm_signed_255 > 0) {
    uint16_t ccr = pwm255_to_ccr(m->period, pwm_signed_255);
    set_ccr(m->htim, m->ch_rpwm, ccr);
    set_ccr(m->htim, m->ch_lpwm, 0);
  } else if (pwm_signed_255 < 0) {
    uint16_t ccr = pwm255_to_ccr(m->period, (int16_t)(-pwm_signed_255));
    set_ccr(m->htim, m->ch_rpwm, 0);
    set_ccr(m->htim, m->ch_lpwm, ccr);
  } else {
    set_ccr(m->htim, m->ch_rpwm, 0);
    set_ccr(m->htim, m->ch_lpwm, 0);
  }
}

void bts_init(bts7960_t *m,
              TIM_HandleTypeDef *htim,
              uint32_t ch_rpwm,
              uint32_t ch_lpwm,
              uint16_t period,
              GPIO_TypeDef *ren_port, uint16_t ren_pin,
              GPIO_TypeDef *len_port, uint16_t len_pin)
{
  m->htim = htim;
  m->ch_rpwm = ch_rpwm;
  m->ch_lpwm = ch_lpwm;
  m->period = period;

  m->ren_port = ren_port;
  m->ren_pin  = ren_pin;
  m->len_port = len_port;
  m->len_pin  = len_pin;

  m->pwm_target  = 0;
  m->pwm_current = 0;
  m->enabled = 0;

  m->ramp_dt_ms = 10;
  m->ramp_step  = 3;
  m->last_ms = HAL_GetTick();

  // safe default: outputs off, disabled
  apply_pwm_raw(m, 0);
  en_write(m->ren_port, m->ren_pin, GPIO_PIN_RESET);
  en_write(m->len_port, m->len_pin, GPIO_PIN_RESET);
}

void bts_set_ramp(bts7960_t *m, uint16_t dt_ms, int16_t step) {
  if (dt_ms < 1) dt_ms = 1;
  if (step < 1) step = 1;
  m->ramp_dt_ms = dt_ms;
  m->ramp_step = step;
}

void bts_enable(bts7960_t *m) {
  m->enabled = 1;
  en_write(m->ren_port, m->ren_pin, GPIO_PIN_SET);
  en_write(m->len_port, m->len_pin, GPIO_PIN_SET);
}

void bts_disable(bts7960_t *m) {
  m->pwm_target = 0;
  m->pwm_current = 0;
  apply_pwm_raw(m, 0);
  en_write(m->ren_port, m->ren_pin, GPIO_PIN_RESET);
  en_write(m->len_port, m->len_pin, GPIO_PIN_RESET);
  m->enabled = 0;
}

void bts_stop(bts7960_t *m) {
  m->pwm_target = 0; // ramp down
}

void bts_set_target_pwm(bts7960_t *m, int16_t pwm_signed_255) {
  pwm_signed_255 = clamp_i16(pwm_signed_255, -255, 255);
  m->pwm_target = pwm_signed_255;

  // auto-enable when target becomes non-zero
  if (!m->enabled && pwm_signed_255 != 0) {
    bts_enable(m);
  }
}

void bts_tick(bts7960_t *m, uint32_t now_ms) {
  if ((uint32_t)(now_ms - m->last_ms) < m->ramp_dt_ms) return;
  m->last_ms += m->ramp_dt_ms;

  int16_t cur = m->pwm_current;
  int16_t tgt = m->pwm_target;

  if (cur < tgt) {
    cur = (int16_t)(cur + m->ramp_step);
    if (cur > tgt) cur = tgt;
  } else if (cur > tgt) {
    cur = (int16_t)(cur - m->ramp_step);
    if (cur < tgt) cur = tgt;
  }

  m->pwm_current = cur;

  // if disabled, keep outputs off
  if (!m->enabled) {
    apply_pwm_raw(m, 0);
    return;
  }

  apply_pwm_raw(m, m->pwm_current);

  // optional auto-disable when reached 0 (safer حراريًا)
  if (m->pwm_current == 0 && m->pwm_target == 0) {
    // لو عايز تفضل enabled سيب السطرين دول معلقين
    en_write(m->ren_port, m->ren_pin, GPIO_PIN_RESET);
    en_write(m->len_port, m->len_pin, GPIO_PIN_RESET);
    m->enabled = 0;
  }
}

int16_t bts_get_target(const bts7960_t *m) { return m->pwm_target; }
int16_t bts_get_current(const bts7960_t *m) { return m->pwm_current; }
uint8_t bts_is_enabled(const bts7960_t *m) { return m->enabled; }



