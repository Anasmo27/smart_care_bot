/*
 * curve.c
 *
 *  Created on: Mar 13, 2026
 *      Author: ASUS
 */

#include "curve.h"
#include <stdlib.h>

static int32_t i32_abs(int32_t x)
{
    return (x >= 0) ? x : -x;
}

static int16_t clamp_i16(int16_t x, int16_t lo, int16_t hi)
{
    if (x < lo) return lo;
    if (x > hi) return hi;
    return x;
}

void curve_init(curve_t *c)
{
    c->outer_motor = NULL;
    c->inner_motor = NULL;
    c->outer_enc = NULL;
    c->inner_enc = NULL;

    c->outer_dir = 1;
    c->inner_dir = 1;

    c->outer_start = 0;
    c->inner_start = 0;

    c->outer_target = 0;
    c->inner_target = 0;

    c->outer_speed = 0;
    c->inner_speed = 0;

    c->ratio_num = 1;
    c->ratio_den = 1;

    c->active = 0;
    c->state = CURVE_IDLE;
}

void curve_start(curve_t *c,
                 bts7960_t *outer_motor, encoder_t *outer_enc, int8_t outer_dir,
                 bts7960_t *inner_motor, encoder_t *inner_enc, int8_t inner_dir,
                 int32_t outer_steps, int16_t outer_speed,
                 int32_t ratio_num, int32_t ratio_den)
{
    if (outer_steps <= 0) return;
    if (ratio_num <= 0 || ratio_den <= 0) return;
    if (outer_steps < 3) return;

    c->outer_motor = outer_motor;
    c->inner_motor = inner_motor;
    c->outer_enc = outer_enc;
    c->inner_enc = inner_enc;

    c->outer_dir = (outer_dir >= 0) ? 1 : -1;
    c->inner_dir = (inner_dir >= 0) ? 1 : -1;

    c->outer_start = encoder_get_count(outer_enc);
    c->inner_start = encoder_get_count(inner_enc);

    c->outer_target = outer_steps;
    c->inner_target = (outer_steps * ratio_num) / ratio_den;

    c->outer_speed = clamp_i16(outer_speed, 1, 255);
    c->inner_speed = clamp_i16((outer_speed * ratio_num) / ratio_den, 1, 255);

    c->ratio_num = ratio_num;
    c->ratio_den = ratio_den;

    c->active = 1;
    c->state = CURVE_RUNNING;

    // Start both together
    bts_set_target_pwm(c->outer_motor, c->outer_dir * c->outer_speed);
    bts_set_target_pwm(c->inner_motor, c->inner_dir * c->inner_speed);
}

void curve_stop(curve_t *c)
{
    if (c->outer_motor) bts_stop(c->outer_motor);
    if (c->inner_motor) bts_stop(c->inner_motor);

    c->active = 0;
    c->state = CURVE_DONE;
}

curve_state_t curve_get_state(curve_t *c)
{
    return c->state;
}

void curve_update(curve_t *c)
{
    if (!c->active) return;

    int32_t outer_now = encoder_get_count(c->outer_enc);
    int32_t inner_now = encoder_get_count(c->inner_enc);

    int32_t outer_travel = i32_abs(outer_now - c->outer_start);
    int32_t inner_travel = i32_abs(inner_now - c->inner_start);

    int32_t outer_remain = c->outer_target - outer_travel;
    if (outer_remain < 0) outer_remain = 0;

    const int32_t OUTER_STOP_DEADBAND = 25;
    const int32_t INNER_HOLD_DEADBAND = 8;

    // If outer wheel reached target -> stop both together
    if (outer_remain <= OUTER_STOP_DEADBAND)
    {
        curve_stop(c);
        return;
    }

    // Inner target follows outer progress
    int32_t inner_target_now = (outer_travel * c->ratio_num) / c->ratio_den;
    int32_t inner_error = inner_target_now - inner_travel;

    // Outer motor decel near end
    int16_t outer_pwm = c->outer_speed;
    int32_t brake_zone = c->outer_target / 3;
    if (brake_zone < 120) brake_zone = 120;
    if (brake_zone < 1) brake_zone = 1;

    if (outer_remain <= brake_zone)
    {
        outer_pwm = (int16_t)((outer_remain * c->outer_speed) / brake_zone);
        if (outer_pwm < 20) outer_pwm = 20;
    }

    bts_set_target_pwm(c->outer_motor, c->outer_dir * outer_pwm);

    // Inner motor follows master progress
    int16_t inner_pwm;

    // بداية الحركة: الداخلية لازم تبدأ فعليًا مع الخارجية
    if (inner_travel < 30)
    {
        inner_pwm = c->inner_speed;
    }
    // لو الداخلية سابقة قليلًا، ما توقفهاش بالكامل
    else if (inner_error <= INNER_HOLD_DEADBAND)
    {
        inner_pwm = 45;
    }
    else if (inner_error < 30)
    {
        inner_pwm = 55;
    }
    else if (inner_error < 60)
    {
        inner_pwm = 65;
    }
    else if (inner_error < 120)
    {
        inner_pwm = c->inner_speed / 2;
        if (inner_pwm < 55) inner_pwm = 55;
    }
    else
    {
        inner_pwm = c->inner_speed;
    }

    if (inner_pwm > c->inner_speed)
        inner_pwm = c->inner_speed;

    bts_set_target_pwm(c->inner_motor, c->inner_dir * inner_pwm);
}
