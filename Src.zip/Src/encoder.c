/*
 * encoder.c
 *
 *  Created on: Mar 8, 2026
 *      Author: ASUS
 */


#include "encoder.h"

#define ENCODER_USE_32BIT_OVERFLOW_SAFE 1

void encoder_init(encoder_t *enc, TIM_HandleTypeDef *htim)
{
    enc->htim = htim;
    enc->count_accum = 0;
    enc->last_cnt = (uint16_t)__HAL_TIM_GET_COUNTER(htim);
}

void encoder_reset(encoder_t *enc)
{
    __HAL_TIM_SET_COUNTER(enc->htim, 0);
    enc->count_accum = 0;
    enc->last_cnt = 0;
}

void encoder_update(encoder_t *enc)
{
    uint16_t now_cnt = (uint16_t)__HAL_TIM_GET_COUNTER(enc->htim);

#if ENCODER_USE_32BIT_OVERFLOW_SAFE
    int32_t diff = (int32_t)now_cnt - (int32_t)enc->last_cnt;

    if (diff < -32768) diff += 65536;
    if (diff > 32767)  diff -= 65536;

    enc->count_accum += diff;
#else
    int16_t delta = (int16_t)(now_cnt - enc->last_cnt);
    enc->count_accum += delta;
#endif

    enc->last_cnt = now_cnt;
}

int32_t encoder_get_count(encoder_t *enc)
{
    return enc->count_accum;
}
