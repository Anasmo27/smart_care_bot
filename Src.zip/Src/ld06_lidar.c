/*
 * ld06_lidar.c
 *
 *  Created on: May 3, 2026
 *      Author: ASUS
 */

#include "ld06_lidar.h"
#include <string.h>

LidarScan_t current_scan;
uint8_t lidar_rx_buffer[LIDAR_RX_BUF_SIZE];

// متغيرات داخلية لعملية الـ Parsing
static uint16_t read_ptr = 0;
static uint8_t parse_state = 0;
static uint8_t pkt_buf[47]; // حجم الـ Packet الثابت في LD06 هو 47 بايت
static uint8_t pkt_idx = 0;

void LD06_Init(void)
{
    memset(&current_scan, 0, sizeof(LidarScan_t));
    current_scan.scan_id = 0;
    current_scan.point_count = 0;

    read_ptr = 0;
    parse_state = 0;
    pkt_idx = 0;
}

// دالة لحساب الـ CRC الخاص بـ LD06
static uint8_t CalCRC8(uint8_t *p, uint8_t len)
{
    uint8_t crc = 0;
    uint16_t i;
    for (i = 0; i < len; i++) {
        crc = crc ^ p[i];
        for (uint8_t j = 0; j < 8; j++) {
            if (crc & 0x01) {
                crc = (crc >> 1) ^ 0x8C;
            } else {
                crc >>= 1;
            }
        }
    }
    return crc;
}

// دالة تفريغ الـ Packet واستخراج النقاط
static void Parse_LD06_Packet(void)
{
    // التحقق من الـ CRC
    if (CalCRC8(pkt_buf, 46) != pkt_buf[46]) {
        return; // CRC Error, تجاهل الحزمة
    }

    // التحقق من زاوية البداية والنهاية
    uint16_t start_angle = (pkt_buf[5] << 8) | pkt_buf[4];
    uint16_t end_angle   = (pkt_buf[43] << 8) | pkt_buf[42];

    // تحديد عدد النقاط في هذه الحزمة (دائماً 12 نقطة في LD06)
    uint8_t point_num = 12;

    // حساب فرق الزاوية بين كل نقطة واللي بعدها
    float diff_angle = 0;
    if (end_angle >= start_angle) {
        diff_angle = (float)(end_angle - start_angle) / (point_num - 1);
    } else {
        diff_angle = (float)(end_angle + 36000 - start_angle) / (point_num - 1);
    }

    // إذا بدأنا دورة جديدة (أو اقتربنا من امتلاء الـ Buffer)، نصفر العداد ونزيد الـ scan_id
    if (current_scan.point_count + point_num > MAX_LIDAR_POINTS || start_angle < 500) {
        current_scan.point_count = 0;
        current_scan.scan_id++;
    }

    // استخراج الـ 12 نقطة
    for (int i = 0; i < point_num; i++) {
        uint16_t dist = (pkt_buf[7 + i*3] << 8) | pkt_buf[6 + i*3];
        // pkt_buf[8 + i*3] هي الـ Intensity، لن نستخدمها حالياً لتوفير المساحة

        float current_angle = (float)start_angle + (diff_angle * i);
        if (current_angle >= 36000.0f) {
            current_angle -= 36000.0f;
        }

        // حفظ النقطة في الـ Buffer الخاص بالـ I2C
        current_scan.points[current_scan.point_count].angle_deg_x100 = (uint16_t)current_angle;
        current_scan.points[current_scan.point_count].distance_mm = dist;
        current_scan.point_count++;
    }
}

// هذه الدالة توضع في الـ while(1) وتقرأ باستمرار ما كتبه الـ DMA
void LD06_Process_DMA_Buffer(UART_HandleTypeDef *huart)
{
    // حساب موقع الكتابة الحالي للـ DMA
    // NDTR يحمل عدد البايتات المتبقية، لذا الموقع = الحجم الكلي - المتبقي
    uint16_t write_ptr = LIDAR_RX_BUF_SIZE - huart->hdmarx->Instance->NDTR;

    while (read_ptr != write_ptr)
    {
        uint8_t byte = lidar_rx_buffer[read_ptr];

        // آلة الحالات (State Machine) لجمع الـ Packet
        switch (parse_state)
        {
            case 0: // انتظار بايت البداية 0x54
                if (byte == 0x54) {
                    pkt_buf[0] = byte;
                    pkt_idx = 1;
                    parse_state = 1;
                }
                break;
            case 1: // انتظار بايت الطول (دائماً 0x2C في LD06)
                if (byte == 0x2C) {
                    pkt_buf[1] = byte;
                    pkt_idx = 2;
                    parse_state = 2;
                } else {
                    parse_state = 0; // فشل
                }
                break;
            case 2: // جمع باقي الـ 47 بايت
                pkt_buf[pkt_idx++] = byte;
                if (pkt_idx == 47) {
                    Parse_LD06_Packet();
                    parse_state = 0;
                }
                break;
        }

        // تحديث مؤشر القراءة الدائري
        read_ptr++;
        if (read_ptr >= LIDAR_RX_BUF_SIZE) {
            read_ptr = 0;
        }
    }
}
