/*
 * motion.c
 *
 * Created on: Mar 13, 2026
 * Author: ASUS
 */

#include "motion.h"
#include <stdlib.h>

#define MOTION_AUX_SLOTS              4U
#define ADV_SETTLE_MIN_WINDOW         60
#define ADV_SETTLE_PROGRESS_TICKS     4
#define ADV_SETTLE_TIME_MS            180U
#define ADV_FORCE_STOP_TIME_MS        900U

typedef struct
{
    motion_t *owner;
    int32_t last_travelled;
    uint32_t last_progress_tick;
    uint32_t brake_enter_tick;
    uint8_t in_use;
} motion_aux_t;

static motion_aux_t g_motion_aux[MOTION_AUX_SLOTS];

static int16_t clamp_i16(int16_t x, int16_t lo, int16_t hi)
{
    if (x < lo) return lo;
    if (x > hi) return hi;
    return x;
}

static int32_t i32_abs(int32_t x)
{
    return (x >= 0) ? x : -x;
}

static motion_aux_t *motion_aux_get(motion_t *m, uint8_t create)
{
    uint32_t i;
    motion_aux_t *free_slot = NULL;

    for (i = 0; i < MOTION_AUX_SLOTS; ++i)
    {
        if (g_motion_aux[i].in_use && (g_motion_aux[i].owner == m))
            return &g_motion_aux[i];

        if ((!g_motion_aux[i].in_use) && (free_slot == NULL))
            free_slot = &g_motion_aux[i];
    }

    if ((create != 0U) && (free_slot != NULL))
    {
        free_slot->owner = m;
        free_slot->last_travelled = 0;
        free_slot->last_progress_tick = HAL_GetTick();
        free_slot->brake_enter_tick = 0U;
        free_slot->in_use = 1U;
        return free_slot;
    }

    return NULL;
}

static void motion_aux_reset(motion_t *m)
{
    motion_aux_t *aux = motion_aux_get(m, 1U);
    if (aux != NULL)
    {
        aux->last_travelled = 0;
        aux->last_progress_tick = HAL_GetTick();
        aux->brake_enter_tick = 0U;
    }
}

void motion_init(motion_t *m, bts7960_t *motor, encoder_t *encoder)
{
    m->motor = motor;
    m->encoder = encoder;

    m->state = MOTION_IDLE;
    m->start_count = 0;
    m->target_counts = 0;
    m->brake_counts = 0;

    m->direction = 1;

    m->max_pwm = 0;
    m->min_pwm = 40;
    m->current_cmd = 0;

    m->active = 0;

    m->adv_enabled = 0;
    m->adv_accel_counts = 1800; // Smoother acceleration
    m->adv_stop_deadband = 15;
    m->adv_brake_min_pwm = 45;
    m->adv_last_pwm_mag = 0;

    m->start_tick = 0U;
    m->timeout_ms = 0U;

    motion_aux_reset(m);
}

void motion_start(motion_t *m, int8_t direction, int32_t steps, int16_t speed_pwm)
{
    int32_t brake_from_speed;
    uint32_t speed_ref;

    if (steps <= 0) return;

    m->adv_enabled = 0;
    m->direction = (direction >= 0) ? 1 : -1;

    m->target_counts = steps;
    m->max_pwm = clamp_i16(speed_pwm, 0, 255);
    if (m->max_pwm < m->min_pwm) m->max_pwm = m->min_pwm;

    m->start_count = encoder_get_count(m->encoder);
    m->current_cmd = 0;
    m->start_tick = HAL_GetTick();

    speed_ref = (uint32_t)m->max_pwm;
    if (speed_ref == 0U) speed_ref = 1U;
    m->timeout_ms = (uint32_t)(((uint32_t)steps * 10U) / speed_ref) + 3000U;

    /* FIX: Brake distance relies purely on speed, NOT total steps */
    brake_from_speed = (int32_t)m->max_pwm * 20;

    m->brake_counts = brake_from_speed;

    if (m->brake_counts < 300)
        m->brake_counts = 300;

    if (m->brake_counts > (steps * 3) / 4)
        m->brake_counts = (steps * 3) / 4;

    m->state = MOTION_RAMP_UP;
    m->active = 1;

    motion_aux_reset(m);
    bts_set_target_pwm(m->motor, 0);
}

void motion_stop(motion_t *m)
{
    motion_aux_t *aux = motion_aux_get(m, 0U);

    m->active = 0;
    m->adv_enabled = 0;
    m->state = MOTION_DONE;
    m->current_cmd = 0;
    m->adv_last_pwm_mag = 0;
    m->start_tick = 0U;
    m->timeout_ms = 0U;
    bts_stop(m->motor);

    if (aux != NULL)
    {
        aux->last_progress_tick = HAL_GetTick();
        aux->brake_enter_tick = 0U;
    }
}

int32_t motion_get_travelled(motion_t *m)
{
    int32_t now = encoder_get_count(m->encoder);
    return i32_abs(now - m->start_count);
}

int32_t motion_get_remaining(motion_t *m)
{
    int32_t t = motion_get_travelled(m);
    int32_t r = m->target_counts - t;
    if (r < 0) r = 0;
    return r;
}

motion_state_t motion_get_state(motion_t *m)
{
    return m->state;
}

void motion_update(motion_t *m)
{
    int32_t travelled;
    int32_t remain;
    const int32_t STOP_DEADBAND = 30;

    if (!m->active) return;

    if ((m->timeout_ms != 0U) && ((HAL_GetTick() - m->start_tick) > m->timeout_ms))
    {
        motion_stop(m);
        return;
    }

    travelled = motion_get_travelled(m);
    remain = m->target_counts - travelled;
    if (remain < 0)
        remain = 0;

    if (remain <= STOP_DEADBAND)
    {
        motion_stop(m);
        return;
    }

    switch (m->state)
    {
        case MOTION_RAMP_UP:
        {
            if (remain <= m->brake_counts)
            {
                m->state = MOTION_RAMP_DOWN;
                break;
            }

            m->current_cmd = m->direction * m->max_pwm;
            bts_set_target_pwm(m->motor, m->current_cmd);

            if (i32_abs(bts_get_current(m->motor)) >= (m->max_pwm - 5))
            {
                m->state = MOTION_CRUISE;
            }
            break;
        }

        case MOTION_CRUISE:
        {
            if (remain <= m->brake_counts)
            {
                m->state = MOTION_RAMP_DOWN;
                break;
            }

            m->current_cmd = m->direction * m->max_pwm;
            bts_set_target_pwm(m->motor, m->current_cmd);
            break;
        }

        case MOTION_RAMP_DOWN:
        {
            int32_t bz = m->brake_counts;
            int16_t pwm_mag;
            int64_t remain64;
            int64_t scaled;

            if (bz <= 0) bz = 1;

            remain64 = (int64_t)remain;
            scaled = (remain64 * remain64) / bz;
            pwm_mag = (int16_t)((scaled * m->max_pwm) / bz);

            if (remain <= 120)
            {
                if (pwm_mag > 18)
                    pwm_mag = 18;
            }
            else if (remain <= 220)
            {
                if (pwm_mag > 28)
                    pwm_mag = 28;
            }
            else if (remain <= 350)
            {
                if (pwm_mag > (m->min_pwm / 2))
                    pwm_mag = m->min_pwm / 2;
            }
            else
            {
                if (pwm_mag < m->min_pwm)
                    pwm_mag = m->min_pwm;
            }

            if (pwm_mag < 0)
                pwm_mag = 0;
            if (pwm_mag > m->max_pwm)
                pwm_mag = m->max_pwm;

            m->current_cmd = m->direction * pwm_mag;
            bts_set_target_pwm(m->motor, m->current_cmd);
            break;
        }

        case MOTION_DONE:
        case MOTION_IDLE:
        default:
            break;
    }
}

void motion_config_adv(motion_t *m, int32_t accel_counts, int32_t stop_deadband, int16_t brake_min_pwm)
{
    if (accel_counts < 40) accel_counts = 40;
    if (stop_deadband < 2) stop_deadband = 2;
    if (brake_min_pwm < 8) brake_min_pwm = 8;

    m->adv_accel_counts = accel_counts;
    m->adv_stop_deadband = stop_deadband;
    m->adv_brake_min_pwm = brake_min_pwm;
}

void motion_start_adv(motion_t *m, int8_t direction, int32_t steps, int16_t speed_pwm)
{
    int32_t brake_from_speed;
    uint32_t speed_ref;

    if (steps <= 0) return;

    m->direction = (direction >= 0) ? 1 : -1;
    m->target_counts = steps;
    m->max_pwm = clamp_i16(speed_pwm, 0, 255);
    if (m->max_pwm < m->min_pwm) m->max_pwm = m->min_pwm;

    m->start_count = encoder_get_count(m->encoder);
    m->current_cmd = 0;
    m->start_tick = HAL_GetTick();

    speed_ref = (uint32_t)m->max_pwm;
    if (speed_ref == 0U) speed_ref = 1U;

    // أعطينا وقت أطول للسماحية لتجنب الـ Timeout
    m->timeout_ms = (uint32_t)(((uint32_t)steps * 10U) / speed_ref) + 3000U;

    /* FIX: Brake distance relies purely on speed, NOT total steps */
    brake_from_speed = (int32_t)m->max_pwm * 20;

    m->brake_counts = brake_from_speed;

    if (m->brake_counts < 300)
        m->brake_counts = 300;

    if (m->brake_counts > (steps * 3) / 4)
        m->brake_counts = (steps * 3) / 4;

    /* FIX: Increased acceleration zone to prevent initial wheel skid */
    m->adv_accel_counts = 1800;
    m->adv_stop_deadband = 15;
    m->adv_brake_min_pwm = 45; // Increased min PWM so it doesn't stall

    m->adv_enabled = 1;
    m->adv_last_pwm_mag = 0;
    m->state = MOTION_RAMP_UP;
    m->active = 1;

    motion_aux_reset(m);
    bts_set_target_pwm(m->motor, 0);
}

void motion_start_distance_cm(motion_t *m, int8_t direction, float distance_cm, int16_t speed_pwm, float ticks_per_cm)
{
    float steps_f;
    int32_t steps;

    if (distance_cm <= 0.0f) return;
    if (ticks_per_cm <= 0.0f) return;

    steps_f = distance_cm * ticks_per_cm;
    if (steps_f < 1.0f) steps_f = 1.0f;
    if (steps_f > 2147480000.0f) steps_f = 2147480000.0f;

    steps = (int32_t)(steps_f + 0.5f);
    motion_start_adv(m, direction, steps, speed_pwm);
}

void motion_update_adv(motion_t *m)
{
    int32_t travelled;
    int32_t remain;
    int32_t accel_zone;
    int32_t brake_zone;
    int32_t stop_window;
    int16_t pwm_mag;
    uint32_t now;
    motion_aux_t *aux;

    if (!m->adv_enabled)
    {
        motion_update(m);
        return;
    }

    if (!m->active) return;

    if ((m->timeout_ms != 0U) && ((HAL_GetTick() - m->start_tick) > m->timeout_ms))
    {
        motion_stop(m);
        return;
    }

    aux = motion_aux_get(m, 1U);
    now = HAL_GetTick();

    travelled = motion_get_travelled(m);
    remain = m->target_counts - travelled;
    if (remain < 0)
        remain = 0;

    if (aux != NULL)
    {
        if ((travelled - aux->last_travelled) >= ADV_SETTLE_PROGRESS_TICKS)
        {
            aux->last_travelled = travelled;
            aux->last_progress_tick = now;
        }
    }

    stop_window = m->adv_stop_deadband;
    if (stop_window < ADV_SETTLE_MIN_WINDOW)
        stop_window = ADV_SETTLE_MIN_WINDOW;
    if (stop_window < ((int32_t)m->adv_brake_min_pwm * 4))
        stop_window = (int32_t)m->adv_brake_min_pwm * 4;
    if (stop_window > 320)
        stop_window = 320;

    if (remain <= m->adv_stop_deadband)
    {
        motion_stop(m);
        return;
    }

    accel_zone = m->adv_accel_counts;
    if (accel_zone < 40) accel_zone = 40;

    brake_zone = m->brake_counts;
    if (brake_zone < 40) brake_zone = 40;

    if (travelled < accel_zone)
    {
        pwm_mag = (int16_t)(m->min_pwm + ((int32_t)(m->max_pwm - m->min_pwm) * travelled) / accel_zone);
        if (pwm_mag < m->min_pwm) pwm_mag = m->min_pwm;
        if (pwm_mag > m->max_pwm) pwm_mag = m->max_pwm;
        m->state = MOTION_RAMP_UP;
        if (aux != NULL)
            aux->brake_enter_tick = 0U;
    }
    else if (remain <= brake_zone)
    {
        uint8_t settle_stop = 0U;

        if ((aux != NULL) && (aux->brake_enter_tick == 0U))
            aux->brake_enter_tick = now;

        if ((aux != NULL) && ((now - aux->last_progress_tick) >= ADV_SETTLE_TIME_MS))
            settle_stop = 1U;

        if ((aux != NULL) && (aux->brake_enter_tick != 0U) &&
            ((now - aux->brake_enter_tick) >= ADV_FORCE_STOP_TIME_MS))
            settle_stop = 1U;

        pwm_mag = (int16_t)(m->adv_brake_min_pwm + ((int32_t)(m->max_pwm - m->adv_brake_min_pwm) * remain) / brake_zone);
        if (pwm_mag < m->adv_brake_min_pwm) pwm_mag = m->adv_brake_min_pwm;
        if (pwm_mag > m->max_pwm) pwm_mag = m->max_pwm;

        if (remain <= stop_window)
        {
            int16_t dynamic_floor;

            /* FIX: Increased dynamic floor to prevent stalling near the end */
            if (m->max_pwm <= 130)
            {
                dynamic_floor = 55;
            }
            else
            {
                dynamic_floor = 45;
            }

            if (pwm_mag < dynamic_floor)
                pwm_mag = dynamic_floor;

            if (pwm_mag > m->max_pwm)
                pwm_mag = m->max_pwm;
        }

        if ((settle_stop != 0U) &&
            ((remain <= 320) ||
             (pwm_mag <= (m->adv_brake_min_pwm + 2)) ||
             ((aux != NULL) && (aux->brake_enter_tick != 0U) &&
              ((now - aux->brake_enter_tick) >= ADV_FORCE_STOP_TIME_MS))))
        {
            motion_stop(m);
            return;
        }

        m->state = MOTION_RAMP_DOWN;
    }
    else
    {
        pwm_mag = m->max_pwm;
        m->state = MOTION_CRUISE;
        if (aux != NULL)
            aux->brake_enter_tick = 0U;
    }

    if (!m->active) return;

    m->adv_last_pwm_mag = pwm_mag;
    m->current_cmd = m->direction * pwm_mag;
    bts_set_target_pwm(m->motor, m->current_cmd);
}
