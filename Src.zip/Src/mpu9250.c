/*
 * mpu9250.c
 *
 * Created on: Apr 10, 2026
 * Author: ASUS
 */

#include "mpu9250.h"
#include <math.h>
#include <string.h>

static HAL_StatusTypeDef mpu_write_reg(I2C_HandleTypeDef *hi2c, uint16_t dev,
                                       uint8_t reg, uint8_t data)
{
    return HAL_I2C_Mem_Write(hi2c, dev, reg, I2C_MEMADD_SIZE_8BIT, &data, 1, 100);
}

static HAL_StatusTypeDef mpu_read_reg(I2C_HandleTypeDef *hi2c, uint16_t dev,
                                      uint8_t reg, uint8_t *data)
{
    return HAL_I2C_Mem_Read(hi2c, dev, reg, I2C_MEMADD_SIZE_8BIT, data, 1, 100);
}

static HAL_StatusTypeDef mpu_read_regs(I2C_HandleTypeDef *hi2c, uint16_t dev,
                                       uint8_t reg, uint8_t *buf, uint16_t len)
{
    return HAL_I2C_Mem_Read(hi2c, dev, reg, I2C_MEMADD_SIZE_8BIT, buf, len, 100);
}

float mpu9250_wrap360(float angle)
{
    while (angle >= 360.0f) angle -= 360.0f;
    while (angle < 0.0f) angle += 360.0f;
    return angle;
}

static float angle_blend_deg(float current, float target, float blend)
{
    float diff = target - current;
    if (diff > 180.0f) diff -= 360.0f;
    if (diff < -180.0f) diff += 360.0f;
    return mpu9250_wrap360(current + blend * diff);
}

static float compute_heading(float mx, float my)
{
    float heading = atan2f(my, mx) * 180.0f / (float)M_PI;
    if (heading < 0.0f) heading += 360.0f;
    return heading;
}

HAL_StatusTypeDef mpu9250_init(mpu9250_t *imu, I2C_HandleTypeDef *hi2c)
{
    uint8_t who = 0;
    HAL_StatusTypeDef st;

    memset(imu, 0, sizeof(*imu));

    imu->gz_bias = 0.0f;
    imu->mag_offset_x = 667.0f;
    imu->mag_offset_y = 376.0f;
    imu->mag_offset_z = 192.5f;

    st = mpu_read_reg(hi2c, MPU9250_I2C_ADDR, MPU9250_WHO_AM_I, &who);
    if (st != HAL_OK || who != 0x71)
    {
        imu->mpu_ok = 0;
        return HAL_ERROR;
    }
    imu->mpu_ok = 1;

    st = mpu_write_reg(hi2c, MPU9250_I2C_ADDR, MPU9250_PWR_MGMT_1, 0x00);
    if (st != HAL_OK) return st;
    HAL_Delay(100);

    // UNLOCK 2000 DPS MODE (0x18)
    // This allows the sensor to read ultra-fast spins without clipping.
    st = mpu_write_reg(hi2c, MPU9250_I2C_ADDR, MPU9250_GYRO_CONFIG, 0x18);
    if (st != HAL_OK) return st;

    st = mpu_write_reg(hi2c, MPU9250_I2C_ADDR, MPU9250_ACCEL_CONFIG, 0x00);
    if (st != HAL_OK) return st;

    st = mpu_write_reg(hi2c, MPU9250_I2C_ADDR, MPU9250_INT_PIN_CFG, 0x02);
    if (st != HAL_OK) return st;
    HAL_Delay(10);

    st = mpu_read_reg(hi2c, AK8963_I2C_ADDR, AK8963_WHO_AM_I, &who);
    if (st != HAL_OK || who != 0x48)
    {
        imu->mag_ok = 0;
        return HAL_ERROR;
    }
    imu->mag_ok = 1;

    st = mpu_write_reg(hi2c, AK8963_I2C_ADDR, AK8963_CNTL2, 0x01);
    if (st != HAL_OK) return st;
    HAL_Delay(50);

    st = mpu_write_reg(hi2c, AK8963_I2C_ADDR, AK8963_CNTL1, 0x00);
    if (st != HAL_OK) return st;
    HAL_Delay(10);

    st = mpu_write_reg(hi2c, AK8963_I2C_ADDR, AK8963_CNTL1, 0x16);
    if (st != HAL_OK) return st;
    HAL_Delay(10);

    imu->last_tick_ms = HAL_GetTick();
    return HAL_OK;
}

HAL_StatusTypeDef mpu9250_read_accel_gyro(mpu9250_t *imu, I2C_HandleTypeDef *hi2c)
{
    uint8_t raw[14];
    HAL_StatusTypeDef st;

    st = mpu_read_regs(hi2c, MPU9250_I2C_ADDR, MPU9250_ACCEL_XOUT_H, raw, 14);
    if (st != HAL_OK) return st;

    imu->ax = (int16_t)((raw[0] << 8) | raw[1]);
    imu->ay = (int16_t)((raw[2] << 8) | raw[3]);
    imu->az = (int16_t)((raw[4] << 8) | raw[5]);

    imu->gx = (int16_t)((raw[8] << 8) | raw[9]);
    imu->gy = (int16_t)((raw[10] << 8) | raw[11]);
    imu->gz = (int16_t)((raw[12] << 8) | raw[13]);

    imu->ax_g = imu->ax / 16384.0f;
    imu->ay_g = imu->ay / 16384.0f;
    imu->az_g = imu->az / 16384.0f;

    // Apply the 2000 DPS scale factor (16.4) to convert raw data to Degrees Per Second
    imu->gx_dps = imu->gx / 16.4f;
    imu->gy_dps = imu->gy / 16.4f;
    imu->gz_dps = imu->gz / 16.4f;

    return HAL_OK;
}

HAL_StatusTypeDef mpu9250_read_mag(mpu9250_t *imu, I2C_HandleTypeDef *hi2c)
{
    uint8_t st1;
    uint8_t data[7];
    HAL_StatusTypeDef st;

    st = mpu_read_reg(hi2c, AK8963_I2C_ADDR, AK8963_ST1, &st1);
    if (st != HAL_OK) return st;

    if ((st1 & 0x01) == 0)
        return HAL_BUSY;

    st = mpu_read_regs(hi2c, AK8963_I2C_ADDR, AK8963_XOUT_L, data, 7);
    if (st != HAL_OK) return st;

    imu->mx = (int16_t)((data[1] << 8) | data[0]);
    imu->my = (int16_t)((data[3] << 8) | data[2]);
    imu->mz = (int16_t)((data[5] << 8) | data[4]);

    return HAL_OK;
}

HAL_StatusTypeDef mpu9250_update(mpu9250_t *imu, I2C_HandleTypeDef *hi2c, uint32_t now_ms)
{
    HAL_StatusTypeDef st_ag;
    HAL_StatusTypeDef st_mag;
    float dt;
    float mx_cal, my_cal;
    float predicted;

    // EMI SHIELD MEMORY: Remembers the last successful speed reading
    static float last_valid_gz_raw = 0.0f;

    dt = (now_ms - imu->last_tick_ms) / 1000.0f;

    // RELAXED TIME CAP: Allow up to 100ms gap.
    if (dt <= 0.0f || dt > 0.1f) {
        dt = 0.005f;
    }
    imu->last_tick_ms = now_ms;

    st_ag = mpu9250_read_accel_gyro(imu, hi2c);
    float gz_raw;

    if (st_ag == HAL_OK)
    {
        gz_raw = imu->gz_dps - imu->gz_bias;

        // Dead-band
        if (gz_raw > -1.5f && gz_raw < 1.5f) {
            gz_raw = 0.0f;
        }
        last_valid_gz_raw = gz_raw;
    }
    else
    {
        // PACKET DROPPED! Assume the robot is still spinning at the exact same speed.
        gz_raw = last_valid_gz_raw;
    }

    /* --- CALCULATE YAW WITH FRESH MULTIPLIERS --- */
    float calibration_multiplier;

    if (gz_raw > 1.5f)
    {
        // TURNING RIGHT
        calibration_multiplier = 0.59f;
    }
    else if (gz_raw < -1.5f)
    {
        // TURNING LEFT
        calibration_multiplier = 0.60f;
    }
    else
    {
        calibration_multiplier = 0.0f;
    }

    float gz_corr = gz_raw * calibration_multiplier;
    imu->yaw_gyro = mpu9250_wrap360(imu->yaw_gyro + gz_corr * dt);

    /* --- READ COMPASS (MAGNETOMETER) --- */
    st_mag = mpu9250_read_mag(imu, hi2c);
    if (st_mag == HAL_OK)
    {
        mx_cal = (float)imu->mx - imu->mag_offset_x;
        my_cal = (float)imu->my - imu->mag_offset_y;

        imu->heading_deg = compute_heading(mx_cal, my_cal);

        predicted = mpu9250_wrap360(imu->yaw_fused + gz_corr * dt);
        imu->yaw_fused = angle_blend_deg(predicted, imu->heading_deg, 0.02f);
    }
    else
    {
        imu->yaw_fused = mpu9250_wrap360(imu->yaw_fused + gz_corr * dt);
    }

    return HAL_OK;
}

HAL_StatusTypeDef mpu9250_calibrate_gyro_z(mpu9250_t *imu, I2C_HandleTypeDef *hi2c, uint16_t samples)
{
    int32_t sum = 0;
    uint16_t i;

    for (i = 0; i < samples; i++)
    {
        uint32_t start = HAL_GetTick();

        if (mpu9250_read_accel_gyro(imu, hi2c) != HAL_OK)
            return HAL_ERROR;

        sum += imu->gz;

        while ((HAL_GetTick() - start) < 5U)
        {
        }
    }

    // Apply the 2000 DPS scale factor (16.4) to the bias calculation
    imu->gz_bias = ((float)sum / samples) / 16.4f;
    return HAL_OK;
}
