/*
 * uart_cmd.c
 *
 *  Created on: Mar 9, 2026
 *      Author: ASUS
 */
#include "uart_cmd.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

static UART_HandleTypeDef *g_huart = NULL;
static motion_t *g_mv1 = NULL;   // MOTOR1 = right wheel
static motion_t *g_mv2 = NULL;   // MOTOR2 = left wheel
static encoder_t *g_e1 = NULL;
static encoder_t *g_e2 = NULL;
static curve_t *g_cv = NULL;

static char rx_line[64];
static char rx_line_shadow[64];
static volatile uint8_t rx_idx = 0;
static volatile uint8_t line_ready = 0;
static volatile uint8_t line_shadow_ready = 0;

static void uart_send(const char *s)
{
    HAL_UART_Transmit(g_huart, (uint8_t*)s, strlen(s), 100);
}

static void uart_sendf(const char *fmt, ...)
{
    char buf[128];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    HAL_UART_Transmit(g_huart, (uint8_t*)buf, strlen(buf), 100);
}

void uart_cmd_init(UART_HandleTypeDef *huart,
                   motion_t *mv1, motion_t *mv2,
                   encoder_t *e1, encoder_t *e2,
                   curve_t *cv)
{
    g_huart = huart;
    g_mv1 = mv1;
    g_mv2 = mv2;
    g_e1 = e1;
    g_e2 = e2;
    g_cv = cv;

    rx_idx = 0;
    line_ready = 0;
    memset(rx_line, 0, sizeof(rx_line));
    memset(rx_line_shadow, 0, sizeof(rx_line_shadow));
    line_shadow_ready = 0;
}

void uart_cmd_rx_byte(uint8_t byte)
{
    if (byte == '\r') return;

    if (byte == '\n')
    {
        rx_line[rx_idx] = '\0';
        rx_idx = 0;
        line_ready = 1;
        return;
    }

    if (rx_idx < sizeof(rx_line) - 1)
        rx_line[rx_idx++] = (char)byte;
    else
        rx_idx = 0;
}

static int8_t parse_dir(char c)
{
    if (c == 'F' || c == 'f') return 1;
    if (c == 'B' || c == 'b') return -1;
    return 0;
}

static void stop_all(void)
{
    curve_stop(g_cv);
    motion_stop(g_mv1);
    motion_stop(g_mv2);
}

static void car_move_same(int8_t dir, int32_t steps, int16_t speed)
{
    curve_stop(g_cv);

    encoder_reset(g_e1);
    encoder_reset(g_e2);

    motion_start(g_mv1, dir, steps, speed);
    motion_start(g_mv2, dir, steps, speed);
}

static void car_turn_in_place_right(int32_t steps, int16_t speed)
{
    curve_stop(g_cv);

    encoder_reset(g_e1);
    encoder_reset(g_e2);

    motion_start(g_mv1, -1, steps, speed); // right backward
    motion_start(g_mv2, +1, steps, speed); // left forward
}

static void car_turn_in_place_left(int32_t steps, int16_t speed)
{
    curve_stop(g_cv);

    encoder_reset(g_e1);
    encoder_reset(g_e2);

    motion_start(g_mv1, +1, steps, speed); // right forward
    motion_start(g_mv2, -1, steps, speed); // left backward
}

static void car_curve_forward_right(int32_t steps, int16_t speed)
{
    stop_all();
    encoder_reset(g_e1);
    encoder_reset(g_e2);

    // left = outer, right = inner
    curve_start(g_cv,g_mv2->motor, g_e2, +1,g_mv1->motor, g_e1, +1,steps, speed,60, 100);
}

static void car_curve_forward_left(int32_t steps, int16_t speed)
{
    stop_all();
    encoder_reset(g_e1);
    encoder_reset(g_e2);

    // right = outer, left = inner
    curve_start(g_cv,
                g_mv1->motor, g_e1, +1,
                g_mv2->motor, g_e2, +1,
                steps, speed,
                70, 100);
}

static void car_curve_backward_right(int32_t steps, int16_t speed)
{
    stop_all();
    encoder_reset(g_e1);
    encoder_reset(g_e2);

    // left = outer, right = inner
    curve_start(g_cv,
                g_mv2->motor, g_e2, -1,
                g_mv1->motor, g_e1, -1,
                steps, speed,
                60, 100);
}

static void car_curve_backward_left(int32_t steps, int16_t speed)
{
    stop_all();
    encoder_reset(g_e1);
    encoder_reset(g_e2);

    // right = outer, left = inner
    curve_start(g_cv,
                g_mv1->motor, g_e1, -1,
                g_mv2->motor, g_e2, -1,
                steps, speed,
                60, 100);
}

static void handle_line(char *line)
{
    char cmd[16] = {0};

    if (sscanf(line, "%15s", cmd) != 1)
    {
        uart_send("ERR\r\n");
        return;
    }

    if (strcmp(cmd, "STAT") == 0)
    {
        uart_sendf("ENC1=%ld ENC2=%ld ST1=%d ST2=%d CV=%d REM1=%ld REM2=%ld\r\n",
                   (long)encoder_get_count(g_e1),
                   (long)encoder_get_count(g_e2),
                   (int)motion_get_state(g_mv1),
                   (int)motion_get_state(g_mv2),
                   (int)curve_get_state(g_cv),
                   (long)motion_get_remaining(g_mv1),
                   (long)motion_get_remaining(g_mv2));
        return;
    }

    if (strcmp(cmd, "STOP") == 0)
    {
        stop_all();
        uart_send("OK STOP\r\n");
        return;
    }

    if ((strcmp(cmd, "MV1") == 0) || (strcmp(cmd, "MV2") == 0) || (strcmp(cmd, "MVA") == 0))
    {
        char dir_c = 0;
        int steps = 0;
        int speed = 0;

        if (sscanf(line, "%15s %c %d %d", cmd, &dir_c, &steps, &speed) != 4)
        {
            uart_send("ERR FORMAT\r\n");
            return;
        }

        int8_t dir = parse_dir(dir_c);
        if (dir == 0 || steps <= 0 || speed <= 0)
        {
            uart_send("ERR ARG\r\n");
            return;
        }

        curve_stop(g_cv);

        if (strcmp(cmd, "MV1") == 0)
        {
            encoder_reset(g_e1);
            motion_start(g_mv1, dir, steps, speed);
            uart_send("OK MV1\r\n");
            return;
        }

        if (strcmp(cmd, "MV2") == 0)
        {
            encoder_reset(g_e2);
            motion_start(g_mv2, dir, steps, speed);
            uart_send("OK MV2\r\n");
            return;
        }

        if (strcmp(cmd, "MVA") == 0)
        {
            encoder_reset(g_e1);
            encoder_reset(g_e2);
            motion_start(g_mv1, dir, steps, speed);
            motion_start(g_mv2, dir, steps, speed);
            uart_send("OK MVA\r\n");
            return;
        }
    }

    if (strcmp(cmd, "CAR") == 0)
    {
        char mode[8] = {0};
        int steps = 0;
        int speed = 0;

        if (sscanf(line, "%15s %7s %d %d", cmd, mode, &steps, &speed) != 4)
        {
            uart_send("ERR FORMAT\r\n");
            return;
        }

        if (steps <= 0 || speed <= 0)
        {
            uart_send("ERR ARG\r\n");
            return;
        }

        if (strcmp(mode, "F") == 0)
        {
            car_move_same(+1, steps, speed);
            uart_send("OK CAR F\r\n");
            return;
        }

        if (strcmp(mode, "B") == 0)
        {
            car_move_same(-1, steps, speed);
            uart_send("OK CAR B\r\n");
            return;
        }

        if (strcmp(mode, "R") == 0)
        {
            car_turn_in_place_right(steps, speed);
            uart_send("OK CAR R\r\n");
            return;
        }

        if (strcmp(mode, "L") == 0)
        {
            car_turn_in_place_left(steps, speed);
            uart_send("OK CAR L\r\n");
            return;
        }

        if (strcmp(mode, "FR") == 0)
        {
            car_curve_forward_right(steps, speed);
            uart_send("OK CAR FR\r\n");
            return;
        }

        if (strcmp(mode, "FL") == 0)
        {
            car_curve_forward_left(steps, speed);
            uart_send("OK CAR FL\r\n");
            return;
        }

        if (strcmp(mode, "BR") == 0)
        {
            car_curve_backward_right(steps, speed);
            uart_send("OK CAR BR\r\n");
            return;
        }

        if (strcmp(mode, "BL") == 0)
        {
            car_curve_backward_left(steps, speed);
            uart_send("OK CAR BL\r\n");
            return;
        }

        uart_send("ERR MODE\r\n");
        return;
    }

    uart_send("ERR\r\n");
}

void uart_cmd_task(void)
{
    if (!line_ready) return;

    __HAL_UART_DISABLE_IT(g_huart, UART_IT_RXNE);

    line_ready = 0;
    strcpy(rx_line_shadow, rx_line);
    rx_idx = 0;
    line_shadow_ready = 1U;

    __HAL_UART_ENABLE_IT(g_huart, UART_IT_RXNE);

    if (line_shadow_ready != 0U)
    {
        line_shadow_ready = 0U;
        handle_line(rx_line_shadow);
    }
}
